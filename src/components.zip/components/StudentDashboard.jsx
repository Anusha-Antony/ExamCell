import { useState } from "react";

/* ─── DATA ─── */
const student = {
  name: "Alex Thompson",
  id: "STU-2024-301",
  rollNo: "CS21B045",
  class: "CS-3A",
  semester: "6th Semester",
  department: "Computer Science",
  avatar: "AT",
  email: "alex.thompson@university.edu",
  phone: "+91 98765 12345",
  section: "A",
  batch: "2021-2025",
  cgpa: "8.5",
  status: "Active",
};

const seatingArrangements = [
  { 
    id: 1, 
    exam: "Computer Networks Final", 
    subject: "CS301", 
    date: "2026-02-06", 
    time: "09:00 AM – 12:00 PM",
    hallName: "Examination Hall A",
    building: "Academic Block 2",
    floor: "2nd Floor",
    seatNumber: "A-47",
    row: "A",
    column: "47",
    invigilator: "Dr. Sarah Johnson",
    instructions: "Carry ID card and admit card. No electronic devices allowed.",
    status: "Upcoming"
  },
  { 
    id: 2, 
    exam: "Database Management Midterm", 
    subject: "CS202", 
    date: "2026-02-08", 
    time: "02:00 PM – 04:00 PM",
    hallName: "Examination Hall B",
    building: "Academic Block 1",
    floor: "1st Floor",
    seatNumber: "B-23",
    row: "B",
    column: "23",
    invigilator: "Prof. Mark Davis",
    instructions: "Only non-programmable calculators permitted.",
    status: "Upcoming"
  },
  { 
    id: 3, 
    exam: "Data Structures Final", 
    subject: "CS201", 
    date: "2026-02-04", 
    time: "09:00 AM – 12:00 PM",
    hallName: "Examination Hall A",
    building: "Academic Block 2",
    floor: "2nd Floor",
    seatNumber: "A-52",
    row: "A",
    column: "52",
    invigilator: "Dr. Emily Chen",
    instructions: "Bring university ID card.",
    status: "Completed"
  },
  { 
    id: 4, 
    exam: "Operating Systems Quiz", 
    subject: "CS302", 
    date: "2026-02-12", 
    time: "11:00 AM – 12:30 PM",
    hallName: "Computer Lab 3",
    building: "IT Block",
    floor: "3rd Floor",
    seatNumber: "C-15",
    row: "C",
    column: "15",
    invigilator: "Dr. Robert Wilson",
    instructions: "Login credentials will be provided at the venue.",
    status: "Upcoming"
  },
];

const examTimetable = [
  { id: 1, subject: "Computer Networks", code: "CS301", date: "2026-02-06", time: "09:00 AM – 12:00 PM", type: "Final", credits: 4 },
  { id: 2, subject: "Database Management", code: "CS202", date: "2026-02-08", time: "02:00 PM – 04:00 PM", type: "Midterm", credits: 3 },
  { id: 3, subject: "Data Structures", code: "CS201", date: "2026-02-04", time: "09:00 AM – 12:00 PM", type: "Final", credits: 4 },
  { id: 4, subject: "Operating Systems", code: "CS302", date: "2026-02-12", time: "11:00 AM – 12:30 PM", type: "Quiz", credits: 3 },
  { id: 5, subject: "Software Engineering", code: "CS303", date: "2026-02-14", time: "02:00 PM – 05:00 PM", type: "Final", credits: 4 },
  { id: 6, subject: "Web Technologies", code: "CS304", date: "2026-02-16", time: "09:00 AM – 11:00 AM", type: "Practical", credits: 2 },
];

const statusLight = {
  Upcoming: { bg: "#fff7ed", text: "#ea580c", border: "#fdba74" },
  Completed: { bg: "#ecfdf5", text: "#059669", border: "#6ee7b7" },
};

const navItems = [
  { id: "seating", label: "Seating Arrangements", icon: "🪑" },
  { id: "timetable", label: "Exam Timetable", icon: "📅" },
  { id: "profile", label: "My Profile", icon: "👤" },
];

/* ─── COMPONENT ─── */
export default function StudentsPage() {
  const [activeNav, setActiveNav] = useState("seating");
  const [activeFilter, setActiveFilter] = useState("All");

  const fmt = (d) => new Date(d).toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" });

  return (
    <div style={{ display: "flex", minHeight: "100vh", fontFamily: "'Segoe UI', system-ui, sans-serif", background: "#f1f5f9" }}>

      {/* ════════════ LEFT SIDEBAR ════════════ */}
      <aside style={{
        width: "280px", flexShrink: 0, position: "sticky", top: 0, height: "100vh",
        background: "linear-gradient(180deg, #1e3a8a 0%, #1e40af 50%, #1e3a8a 100%)",
        borderRight: "1px solid rgba(59,130,246,0.15)",
        display: "flex", flexDirection: "column",
        boxShadow: "4px 0 20px rgba(0,0,0,0.08)",
      }}>
        {/* Logo Header */}
        <div style={{ padding: "24px 20px", borderBottom: "1px solid rgba(59,130,246,0.15)" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
            <div style={{
              width: "44px", height: "44px", borderRadius: "12px",
              background: "linear-gradient(135deg, #3b82f6, #2563eb)",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: "20px", boxShadow: "0 4px 16px rgba(59,130,246,0.4)",
            }}>📚</div>
            <div>
              <div style={{ fontSize: "17px", fontWeight: "700", color: "#fff", letterSpacing: "-0.5px" }}>ExamCell</div>
              <div style={{ fontSize: "10px", color: "rgba(255,255,255,0.5)", textTransform: "uppercase", letterSpacing: "1.2px", fontWeight: "600" }}>Student Portal</div>
            </div>
          </div>
        </div>

        {/* Student Profile Card - Clickable */}
        <div 
          onClick={() => setActiveNav("profile")}
          style={{ 
            padding: "20px 18px", 
            borderBottom: "1px solid rgba(59,130,246,0.15)",
            cursor: "pointer",
            transition: "all 0.2s",
            background: activeNav === "profile" ? "rgba(59,130,246,0.12)" : "transparent",
          }}
          onMouseEnter={(e) => { if (activeNav !== "profile") e.currentTarget.style.background = "rgba(255,255,255,0.05)"; }}
          onMouseLeave={(e) => { if (activeNav !== "profile") e.currentTarget.style.background = "transparent"; }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: "14px" }}>
            {/* Avatar with online indicator */}
            <div style={{ position: "relative", flexShrink: 0 }}>
              <div style={{
                width: "56px", height: "56px", borderRadius: "50%",
                background: "linear-gradient(135deg, #3b82f6, #60a5fa)",
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: "20px", fontWeight: "700", color: "#fff",
                boxShadow: "0 0 0 3px #1e3a8a, 0 0 0 5px #3b82f6",
              }}>{student.avatar}</div>
              <div style={{
                position: "absolute", bottom: "0", right: "0",
                width: "14px", height: "14px", borderRadius: "50%",
                background: "#22c55e", border: "2px solid #1e3a8a",
                boxShadow: "0 0 6px rgba(34,197,94,0.6)",
              }}></div>
            </div>

            {/* Student Info */}
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: "15px", fontWeight: "700", color: "#fff", letterSpacing: "-0.3px", marginBottom: "2px" }}>{student.name}</div>
              <div style={{ fontSize: "11px", color: "#93c5fd", fontWeight: "600", marginBottom: "4px" }}>{student.rollNo}</div>
              <div style={{
                display: "inline-block",
                padding: "2px 8px", borderRadius: "12px",
                background: "rgba(59,130,246,0.2)", border: "1px solid rgba(59,130,246,0.4)",
                fontSize: "9px", fontWeight: "700", color: "rgba(255,255,255,0.8)",
                letterSpacing: "0.5px", textTransform: "uppercase",
              }}>{student.class}</div>
            </div>

            {/* Click indicator */}
            {activeNav === "profile" && (
              <div style={{ 
                width: "8px", height: "8px", borderRadius: "50%", 
                background: "#3b82f6", boxShadow: "0 0 8px #3b82f6",
                flexShrink: 0,
              }}></div>
            )}
          </div>
        </div>

        {/* Navigation Links */}
        <nav style={{ flex: 1, padding: "12px", overflowY: "auto" }}>
          <div style={{ fontSize: "10px", color: "rgba(255,255,255,0.4)", textTransform: "uppercase", letterSpacing: "1px", fontWeight: "700", padding: "8px 12px", marginBottom: "4px" }}>Navigation</div>
          {navItems.map((item) => {
            const active = activeNav === item.id;
            return (
              <button key={item.id} onClick={() => setActiveNav(item.id)} style={{
                width: "100%", display: "flex", alignItems: "center", gap: "12px",
                padding: "12px 14px", borderRadius: "10px", border: "none", cursor: "pointer",
                marginBottom: "4px", textAlign: "left", transition: "all 0.2s",
                background: active ? "linear-gradient(135deg, rgba(59,130,246,0.25), rgba(37,99,235,0.15))" : "transparent",
                color: active ? "#93c5fd" : "rgba(255,255,255,0.5)",
                boxShadow: active ? "0 0 0 1px rgba(59,130,246,0.3)" : "none",
                fontWeight: active ? "600" : "500",
              }}
                onMouseEnter={(e) => { if (!active) { e.currentTarget.style.background = "rgba(255,255,255,0.06)"; e.currentTarget.style.color = "rgba(255,255,255,0.8)"; }}}
                onMouseLeave={(e) => { if (!active) { e.currentTarget.style.background = "transparent"; e.currentTarget.style.color = "rgba(255,255,255,0.5)"; }}}
              >
                <span style={{ fontSize: "17px", width: "20px", textAlign: "center" }}>{item.icon}</span>
                <span style={{ fontSize: "13px" }}>{item.label}</span>
                {active && <div style={{ marginLeft: "auto", width: "6px", height: "6px", borderRadius: "50%", background: "#3b82f6", boxShadow: "0 0 8px #3b82f6" }}></div>}
              </button>
            );
          })}
        </nav>

        {/* Footer Stats */}
        <div style={{ padding: "16px 18px", borderTop: "1px solid rgba(59,130,246,0.15)" }}>
          <div style={{ fontSize: "10px", color: "rgba(255,255,255,0.4)", textTransform: "uppercase", letterSpacing: "0.8px", fontWeight: "700", marginBottom: "10px" }}>Quick Stats</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px" }}>
            <div style={{ padding: "10px", borderRadius: "8px", background: "rgba(59,130,246,0.1)", border: "1px solid rgba(59,130,246,0.2)" }}>
              <div style={{ fontSize: "20px", fontWeight: "700", color: "#93c5fd", marginBottom: "2px" }}>{seatingArrangements.filter(s => s.status === "Upcoming").length}</div>
              <div style={{ fontSize: "9px", color: "rgba(255,255,255,0.5)", textTransform: "uppercase", letterSpacing: "0.5px" }}>Upcoming</div>
            </div>
            <div style={{ padding: "10px", borderRadius: "8px", background: "rgba(59,130,246,0.1)", border: "1px solid rgba(59,130,246,0.2)" }}>
              <div style={{ fontSize: "20px", fontWeight: "700", color: "#93c5fd", marginBottom: "2px" }}>{examTimetable.length}</div>
              <div style={{ fontSize: "9px", color: "rgba(255,255,255,0.5)", textTransform: "uppercase", letterSpacing: "0.5px" }}>Total Exams</div>
            </div>
          </div>
        </div>
      </aside>

      {/* ════════════ MAIN CONTENT ════════════ */}
      <main style={{ flex: 1, overflowY: "auto", padding: "32px 40px", minWidth: 0 }}>

        {/* ─── SEATING ARRANGEMENTS PAGE ─── */}
        {activeNav === "seating" && (
          <div>
            {/* Page Header */}
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "28px" }}>
              <div>
                <h1 style={{ margin: 0, fontSize: "26px", fontWeight: "700", color: "#1e293b", letterSpacing: "-0.5px" }}>🪑 Seating Arrangements</h1>
                <p style={{ margin: "6px 0 0", fontSize: "14px", color: "#94a3b8" }}>Your assigned seats for all examinations</p>
              </div>
              <div style={{ 
                padding: "8px 16px", borderRadius: "10px", 
                background: "#eff6ff", border: "1px solid #bfdbfe", 
                fontSize: "13px", color: "#1e40af", fontWeight: "600",
                boxShadow: "0 2px 6px rgba(30,64,175,0.1)",
              }}>
                🔔 {seatingArrangements.filter((s) => s.status === "Upcoming").length} Upcoming Exams
              </div>
            </div>

            {/* Stats Cards */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "18px", marginBottom: "28px" }}>
              {[
                { label: "Total Exams",  value: seatingArrangements.length,                                          icon: "📋", accent: "#1e40af", bg: "#eff6ff" },
                { label: "Upcoming",      value: seatingArrangements.filter((s) => s.status === "Upcoming").length,   icon: "⏳", accent: "#ea580c", bg: "#fff7ed" },
                { label: "Completed",     value: seatingArrangements.filter((s) => s.status === "Completed").length,  icon: "✅", accent: "#059669", bg: "#ecfdf5" },
              ].map((s, i) => (
                <div key={i} style={{
                  background: "#fff", borderRadius: "14px", padding: "20px",
                  border: "1px solid #e2e8f0", display: "flex", alignItems: "center", gap: "16px",
                  boxShadow: "0 2px 6px rgba(0,0,0,0.06)", transition: "all 0.2s",
                }}
                  onMouseEnter={(e) => { e.currentTarget.style.borderColor = s.accent + "50"; e.currentTarget.style.boxShadow = `0 4px 14px ${s.accent}18`; }}
                  onMouseLeave={(e) => { e.currentTarget.style.borderColor = "#e2e8f0"; e.currentTarget.style.boxShadow = "0 2px 6px rgba(0,0,0,0.06)"; }}
                >
                  <div style={{ 
                    width: "52px", height: "52px", borderRadius: "12px", 
                    background: s.bg, border: `1px solid ${s.accent}30`, 
                    display: "flex", alignItems: "center", justifyContent: "center", 
                    fontSize: "22px", flexShrink: 0,
                  }}>{s.icon}</div>
                  <div>
                    <div style={{ fontSize: "28px", fontWeight: "700", color: "#1e293b", lineHeight: "1" }}>{s.value}</div>
                    <div style={{ fontSize: "12px", color: "#94a3b8", marginTop: "4px" }}>{s.label}</div>
                  </div>
                </div>
              ))}
            </div>

            {/* Filter Pills */}
            <div style={{ display: "flex", gap: "10px", marginBottom: "22px", flexWrap: "wrap" }}>
              {["All", "Upcoming", "Completed"].map((f) => {
                const isActive = activeFilter === f;
                return (
                  <span key={f} onClick={() => setActiveFilter(f)} style={{
                    padding: "7px 18px", borderRadius: "20px", fontSize: "13px", fontWeight: "600", cursor: "pointer", transition: "all 0.2s",
                    background: isActive ? "#1e40af" : "#fff",
                    color: isActive ? "#fff" : "#64748b",
                    border: isActive ? "1px solid #1e40af" : "1px solid #e2e8f0",
                    boxShadow: isActive ? "0 3px 10px rgba(30,64,175,0.3)" : "0 1px 3px rgba(0,0,0,0.05)",
                  }}
                    onMouseEnter={(e) => { if (!isActive) { e.currentTarget.style.background = "#f8fafc"; e.currentTarget.style.borderColor = "#cbd5e1"; }}}
                    onMouseLeave={(e) => { if (!isActive) { e.currentTarget.style.background = "#fff"; e.currentTarget.style.borderColor = "#e2e8f0"; }}}
                  >{f}</span>
                );
              })}
            </div>

            {/* Seating Cards */}
            <div style={{ display: "grid", gap: "16px" }}>
              {seatingArrangements
                .filter((s) => activeFilter === "All" || s.status === activeFilter)
                .map((seat) => {
                  const ss = statusLight[seat.status];
                  return (
                    <div key={seat.id} style={{
                      background: "#fff", borderRadius: "14px",
                      border: "1px solid #e2e8f0", overflow: "hidden", transition: "all 0.22s",
                      boxShadow: "0 2px 6px rgba(0,0,0,0.06)",
                    }}
                      onMouseEnter={(e) => { e.currentTarget.style.borderColor = "#1e40af"; e.currentTarget.style.boxShadow = "0 6px 16px rgba(30,64,175,0.18)"; e.currentTarget.style.transform = "translateY(-2px)"; }}
                      onMouseLeave={(e) => { e.currentTarget.style.borderColor = "#e2e8f0"; e.currentTarget.style.boxShadow = "0 2px 6px rgba(0,0,0,0.06)"; e.currentTarget.style.transform = "translateY(0)"; }}
                    >
                      <div style={{ height: "4px", background: seat.status === "Upcoming" ? "linear-gradient(90deg,#3b82f6,#60a5fa)" : "linear-gradient(90deg,#34d399,#6ee7b7)" }}></div>
                      
                      <div style={{ padding: "20px 22px" }}>
                        {/* Header */}
                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "16px" }}>
                          <div>
                            <div style={{ fontSize: "18px", fontWeight: "700", color: "#1e293b", marginBottom: "4px" }}>{seat.exam}</div>
                            <div style={{ fontSize: "13px", color: "#94a3b8", fontWeight: "500" }}>{seat.subject}</div>
                          </div>
                          <span style={{ 
                            fontSize: "11px", fontWeight: "700", padding: "5px 12px", 
                            borderRadius: "20px", background: ss.bg, color: ss.text, 
                            border: `1px solid ${ss.border}`, textTransform: "uppercase", 
                            letterSpacing: "0.5px" 
                          }}>{seat.status}</span>
                        </div>

                        {/* Date & Time Info */}
                        <div style={{ display: "flex", gap: "10px", marginBottom: "18px", flexWrap: "wrap" }}>
                          <div style={{ 
                            display: "flex", alignItems: "center", gap: "6px", 
                            padding: "6px 12px", borderRadius: "8px", 
                            background: "#fef3c7", border: "1px solid #fcd34d" 
                          }}>
                            <span style={{ fontSize: "14px" }}>📅</span>
                            <span style={{ fontSize: "12px", fontWeight: "600", color: "#92400e" }}>{fmt(seat.date)}</span>
                          </div>
                          <div style={{ 
                            display: "flex", alignItems: "center", gap: "6px", 
                            padding: "6px 12px", borderRadius: "8px", 
                            background: "#dbeafe", border: "1px solid #93c5fd" 
                          }}>
                            <span style={{ fontSize: "14px" }}>🕐</span>
                            <span style={{ fontSize: "12px", fontWeight: "600", color: "#1e40af" }}>{seat.time}</span>
                          </div>
                        </div>

                        {/* Seat Information - Highlighted */}
                        <div style={{ 
                          padding: "16px 18px", borderRadius: "12px", 
                          background: "linear-gradient(135deg, #eff6ff, #dbeafe)", 
                          border: "2px solid #3b82f6",
                          marginBottom: "18px",
                          boxShadow: "0 2px 8px rgba(59,130,246,0.15)",
                        }}>
                          <div style={{ fontSize: "11px", color: "#1e40af", textTransform: "uppercase", letterSpacing: "0.8px", fontWeight: "700", marginBottom: "10px" }}>🪑 Your Seat Assignment</div>
                          <div style={{ display: "flex", alignItems: "center", gap: "16px", marginBottom: "12px" }}>
                            <div style={{ 
                              width: "70px", height: "70px", borderRadius: "12px",
                              background: "linear-gradient(135deg, #3b82f6, #2563eb)",
                              display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
                              boxShadow: "0 4px 12px rgba(59,130,246,0.3)",
                            }}>
                              <div style={{ fontSize: "24px", fontWeight: "700", color: "#fff" }}>{seat.seatNumber}</div>
                              <div style={{ fontSize: "9px", color: "#dbeafe", textTransform: "uppercase", letterSpacing: "0.5px" }}>Seat No.</div>
                            </div>
                            <div>
                              <div style={{ display: "flex", gap: "12px", marginBottom: "6px" }}>
                                <div>
                                  <div style={{ fontSize: "10px", color: "#64748b", marginBottom: "2px" }}>Row</div>
                                  <div style={{ fontSize: "16px", fontWeight: "700", color: "#1e40af" }}>{seat.row}</div>
                                </div>
                                <div style={{ width: "1px", background: "#cbd5e1" }}></div>
                                <div>
                                  <div style={{ fontSize: "10px", color: "#64748b", marginBottom: "2px" }}>Column</div>
                                  <div style={{ fontSize: "16px", fontWeight: "700", color: "#1e40af" }}>{seat.column}</div>
                                </div>
                              </div>
                            </div>
                          </div>
                          
                          {/* Location Details */}
                          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "8px" }}>
                            <div style={{ padding: "8px 10px", borderRadius: "8px", background: "#fff", border: "1px solid #e2e8f0" }}>
                              <div style={{ fontSize: "9px", color: "#94a3b8", textTransform: "uppercase", letterSpacing: "0.6px", fontWeight: "600", marginBottom: "3px" }}>Hall</div>
                              <div style={{ fontSize: "12px", fontWeight: "600", color: "#1e293b" }}>{seat.hallName}</div>
                            </div>
                            <div style={{ padding: "8px 10px", borderRadius: "8px", background: "#fff", border: "1px solid #e2e8f0" }}>
                              <div style={{ fontSize: "9px", color: "#94a3b8", textTransform: "uppercase", letterSpacing: "0.6px", fontWeight: "600", marginBottom: "3px" }}>Building</div>
                              <div style={{ fontSize: "12px", fontWeight: "600", color: "#1e293b" }}>{seat.building}</div>
                            </div>
                          </div>
                        </div>

                        {/* Additional Info */}
                        <div style={{ display: "grid", gap: "10px" }}>
                          <div style={{ display: "flex", alignItems: "center", gap: "10px", padding: "10px 12px", borderRadius: "8px", background: "#f8fafc", border: "1px solid #e2e8f0" }}>
                            <span style={{ fontSize: "16px" }}>👨‍🏫</span>
                            <div>
                              <div style={{ fontSize: "10px", color: "#94a3b8", textTransform: "uppercase", letterSpacing: "0.6px", fontWeight: "600" }}>Invigilator</div>
                              <div style={{ fontSize: "13px", fontWeight: "600", color: "#1e293b" }}>{seat.invigilator}</div>
                            </div>
                          </div>
                          
                          <div style={{ padding: "12px 14px", borderRadius: "8px", background: "#fef3c7", border: "1px solid #fde68a" }}>
                            <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "6px" }}>
                              <span style={{ fontSize: "14px" }}>ℹ️</span>
                              <span style={{ fontSize: "11px", color: "#92400e", fontWeight: "700", textTransform: "uppercase", letterSpacing: "0.5px" }}>Instructions</span>
                            </div>
                            <p style={{ margin: 0, fontSize: "12px", color: "#78350f", lineHeight: "1.6" }}>{seat.instructions}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>
        )}

        {/* ─── TIMETABLE PAGE ─── */}
        {activeNav === "timetable" && (
          <div>
            {/* Page Header */}
            <div style={{ marginBottom: "28px" }}>
              <h1 style={{ margin: 0, fontSize: "26px", fontWeight: "700", color: "#1e293b", letterSpacing: "-0.5px" }}>📅 Examination Timetable</h1>
              <p style={{ margin: "6px 0 0", fontSize: "14px", color: "#94a3b8" }}>Your complete exam schedule for the semester</p>
            </div>

            {/* Timetable Info Card */}
            <div style={{
              marginBottom: "24px", padding: "18px 22px", borderRadius: "14px",
              background: "#eff6ff", border: "1px solid #bfdbfe",
              display: "flex", alignItems: "center", gap: "16px",
            }}>
              <div style={{ 
                width: "42px", height: "42px", borderRadius: "50%", 
                background: "#dbeafe", display: "flex", alignItems: "center", 
                justifyContent: "center", fontSize: "20px", flexShrink: 0 
              }}>ℹ️</div>
              <div>
                <div style={{ fontSize: "15px", fontWeight: "700", color: "#1e40af", marginBottom: "3px" }}>Important Information</div>
                <div style={{ fontSize: "13px", color: "#64748b" }}>Report to the examination hall 15 minutes before the scheduled time. Carry your ID card and admit card.</div>
              </div>
            </div>

            {/* Timetable Table */}
            <div style={{ 
              background: "#fff", 
              borderRadius: "14px", 
              overflow: "hidden", 
              border: "1px solid #e2e8f0",
              boxShadow: "0 2px 8px rgba(0,0,0,0.06)",
            }}>
              {/* Table Header */}
              <div style={{ 
                display: "grid", 
                gridTemplateColumns: "0.8fr 1.2fr 1.1fr 1.3fr 0.6fr",
                background: "linear-gradient(135deg, #1e40af, #3b82f6)",
                padding: "16px 20px",
                gap: "12px",
              }}>
                {["Date", "Subject", "Code", "Time", "Credits"].map((header) => (
                  <div key={header} style={{ 
                    fontSize: "12px", 
                    fontWeight: "700", 
                    color: "#fff", 
                    textTransform: "uppercase", 
                    letterSpacing: "0.5px" 
                  }}>{header}</div>
                ))}
              </div>

              {/* Table Rows */}
              <div>
                {examTimetable.map((exam, index) => {
                  const isPast = new Date(exam.date) < new Date();
                  return (
                    <div 
                      key={exam.id} 
                      style={{
                        display: "grid",
                        gridTemplateColumns: "0.8fr 1.2fr 1fr 1.2fr 0.9fr",
                        padding: "16px 20px",
                        gap: "12px",
                        borderBottom: index < examTimetable.length - 1 ? "1px solid #e2e8f0" : "none",
                        background: isPast ? "#f8fafc" : index % 2 === 0 ? "#fff" : "#f8fafc",
                        opacity: isPast ? 0.5 : 1,
                        transition: "all 0.2s",
                      }}
                      onMouseEnter={(e) => { if (!isPast) e.currentTarget.style.background = "#eff6ff"; }}
                      onMouseLeave={(e) => { if (!isPast) e.currentTarget.style.background = index % 2 === 0 ? "#fff" : "#f8fafc"; }}
                    >
                      <div style={{ display: "flex", alignItems: "center" }}>
                        <div>
                          <div style={{ fontSize: "13px", fontWeight: "700", color: "#1e293b" }}>
                            {new Date(exam.date).toLocaleDateString("en-US", { day: "numeric", month: "short" })}
                          </div>
                          <div style={{ fontSize: "11px", color: "#64748b" }}>
                            {new Date(exam.date).toLocaleDateString("en-US", { weekday: "short" })}
                          </div>
                        </div>
                      </div>
                      <div style={{ display: "flex", alignItems: "center" }}>
                        <div style={{ fontSize: "13px", fontWeight: "600", color: "#1e293b" }}>{exam.subject}</div>
                      </div>
                      <div style={{ display: "flex", alignItems: "center" }}>
                        <div style={{ 
                          fontSize: "12px", 
                          fontWeight: "600", 
                          color: "#3b82f6",
                          padding: "4px 10px",
                          background: "#eff6ff",
                          borderRadius: "6px",
                          border: "1px solid #bfdbfe",
                        }}>{exam.code}</div>
                      </div>
                      <div style={{ display: "flex", alignItems: "center" }}>
                        <div style={{ fontSize: "12px", fontWeight: "500", color: "#64748b" }}>{exam.time}</div>
                      </div>
                      
                      <div style={{ display: "flex", alignItems: "center" }}>
                        <div style={{ fontSize: "13px", fontWeight: "600", color: "#1e293b", textAlign: "center", width: "100%" }}>{exam.credits}</div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Table Footer */}
              <div style={{ 
                padding: "14px 20px", 
                background: "#f8fafc", 
                borderTop: "2px solid #e2e8f0",
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
              }}>
                <div style={{ fontSize: "12px", color: "#64748b", fontWeight: "600" }}>
                  Total Examinations: <span style={{ color: "#1e40af", fontWeight: "700" }}>{examTimetable.length}</span>
                </div>
                <div style={{ fontSize: "12px", color: "#64748b", fontWeight: "600" }}>
                  Total Credits: <span style={{ color: "#1e40af", fontWeight: "700" }}>{examTimetable.reduce((sum, exam) => sum + exam.credits, 0)}</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ─── PROFILE PAGE ─── */}
        {activeNav === "profile" && (
          <div>
            {/* Page Header */}
            <div style={{ marginBottom: "28px" }}>
              <h1 style={{ margin: 0, fontSize: "26px", fontWeight: "700", color: "#1e293b", letterSpacing: "-0.5px" }}>👤 Student Profile</h1>
              <p style={{ margin: "6px 0 0", fontSize: "14px", color: "#94a3b8" }}>Your complete academic profile and details</p>
            </div>

            {/* Main Profile Card */}
            <div style={{ background: "#fff", borderRadius: "16px", overflow: "hidden", boxShadow: "0 2px 8px rgba(0,0,0,0.08)", marginBottom: "24px" }}>
              {/* Header Banner */}
              <div style={{ 
                height: "120px", 
                background: "linear-gradient(135deg, #1e3a8a 0%, #1e40af 50%, #3b82f6 100%)",
                position: "relative",
              }}>
                <div style={{ position: "absolute", bottom: "-50px", left: "32px" }}>
                  <div style={{
                    width: "100px", height: "100px", borderRadius: "50%",
                    background: "linear-gradient(135deg, #3b82f6, #60a5fa)",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    fontSize: "36px", fontWeight: "700", color: "#fff",
                    boxShadow: "0 0 0 6px #fff, 0 4px 20px rgba(0,0,0,0.15)",
                  }}>{student.avatar}</div>
                </div>
              </div>

              {/* Profile Content */}
              <div style={{ padding: "60px 32px 32px" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "start", marginBottom: "24px" }}>
                  <div>
                    <h2 style={{ margin: 0, fontSize: "24px", fontWeight: "700", color: "#1e293b", marginBottom: "6px" }}>{student.name}</h2>
                    <p style={{ margin: 0, fontSize: "15px", color: "#1e40af", fontWeight: "600", marginBottom: "8px" }}>{student.rollNo}</p>
                    <div style={{ display: "flex", gap: "10px", flexWrap: "wrap" }}>
                      <span style={{ 
                        padding: "4px 12px", borderRadius: "20px", 
                        background: "#eff6ff", border: "1px solid #bfdbfe",
                        fontSize: "11px", fontWeight: "700", color: "#1e40af",
                        textTransform: "uppercase", letterSpacing: "0.5px"
                      }}>{student.id}</span>
                      <span style={{ 
                        padding: "4px 12px", borderRadius: "20px", 
                        background: "#ecfdf5", border: "1px solid #6ee7b7",
                        fontSize: "11px", fontWeight: "700", color: "#059669",
                        textTransform: "uppercase", letterSpacing: "0.5px"
                      }}>● {student.status}</span>
                    </div>
                  </div>
                </div>

                {/* Info Grid */}
                <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: "20px", marginBottom: "28px" }}>
                  {[
                    { icon: "✉️", label: "Email", value: student.email, color: "#0891b2" },
                    { icon: "📞", label: "Phone", value: student.phone, color: "#1e40af" },
                    { icon: "🏛️", label: "Department", value: student.department, color: "#7c3aed" },
                    { icon: "📚", label: "Semester", value: student.semester, color: "#db2777" },
                    { icon: "🎓", label: "Batch", value: student.batch, color: "#ea580c" },
                    { icon: "📊", label: "CGPA", value: student.cgpa, color: "#059669" },
                  ].map((item, i) => (
                    <div key={i} style={{
                      padding: "16px 18px", borderRadius: "12px",
                      background: "#f8fafc", border: "1px solid #e2e8f0",
                      display: "flex", alignItems: "center", gap: "12px",
                      transition: "all 0.2s",
                    }}
                      onMouseEnter={(e) => { e.currentTarget.style.borderColor = item.color + "50"; e.currentTarget.style.boxShadow = `0 2px 10px ${item.color}15`; }}
                      onMouseLeave={(e) => { e.currentTarget.style.borderColor = "#e2e8f0"; e.currentTarget.style.boxShadow = "none"; }}
                    >
                      <div style={{ 
                        width: "40px", height: "40px", borderRadius: "10px",
                        background: item.color + "10", border: `1px solid ${item.color}30`,
                        display: "flex", alignItems: "center", justifyContent: "center",
                        fontSize: "18px", flexShrink: 0,
                      }}>{item.icon}</div>
                      <div style={{ minWidth: 0 }}>
                        <div style={{ fontSize: "10px", color: "#94a3b8", textTransform: "uppercase", letterSpacing: "0.6px", fontWeight: "600", marginBottom: "3px" }}>{item.label}</div>
                        <div style={{ fontSize: "13px", fontWeight: "600", color: "#1e293b", wordBreak: "break-all" }}>{item.value}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      <style>{`
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 3px; }
        ::-webkit-scrollbar-thumb:hover { background: #94a3b8; }
      `}</style>
    </div>
  );
}