import React, { useState } from 'react';
import { Users, Search, Filter, Plus, Edit2, Trash2, Download, Upload, Mail, Phone, Award, Eye, UserCheck } from 'lucide-react';

export default function FacultyManagement() {
  const [faculty, setFaculty] = useState([
    {
      id: 1,
      name: 'Dr. Rajesh Kumar',
      employeeId: 'FAC001',
      designation: 'Professor',
      department: 'Computer Science',
      email: 'rajesh.kumar@faculty.edu',
      phone: '9876543210',
      experience: '15 years',
      status: 'Active'
    },
   
    {
      id: 3,
      name: 'Mr. Arun Menon',
      employeeId: 'FAC003',
      designation: 'Assistant Professor',
      department: 'Computer Science',
      email: 'arun.menon@faculty.edu',
      phone: '9876543212',
      experience: '8 years',
      status: 'Active'
    },
  
    {
      id: 5,
      name: 'Mr. Suresh Babu',
      employeeId: 'FAC005',
      designation: 'Lab Staff',
      department: 'Computer Science',
      email: 'suresh.babu@faculty.edu',
      phone: '9876543214',
      experience: '10 years',
      status: 'Active'
    }
  ]);

  const [searchQuery, setSearchQuery] = useState('');
  const [filterDepartment, setFilterDepartment] = useState('');
  const [filterDesignation, setFilterDesignation] = useState('');

  const departments = ['Computer Science', 'Electronics', 'Mechanical', 'Civil', 'Information Technology'];
  const designations = ['Professor', 'Associate Professor', 'Assistant Professor', 'Senior Lecturer', 'Lecturer', 'Lab Staff'];

  const filteredFaculty = faculty.filter(member => {
    const matchesSearch = searchQuery
      ? member.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        member.employeeId.toLowerCase().includes(searchQuery.toLowerCase()) ||
        member.email.toLowerCase().includes(searchQuery.toLowerCase())
      : true;
    const matchesDepartment = filterDepartment ? member.department === filterDepartment : true;
    const matchesDesignation = filterDesignation ? member.designation === filterDesignation : true;
    return matchesSearch && matchesDepartment && matchesDesignation;
  });

  const handleDeleteFaculty = (id) => {
    if (window.confirm('Are you sure you want to delete this faculty member?')) {
      setFaculty(faculty.filter(f => f.id !== id));
    }
  };

  const getDesignationColor = (designation) => {
    const colors = {
      'Professor': 'from-purple-500 to-pink-600',
      'Associate Professor': 'from-blue-500 to-indigo-600',
      'Assistant Professor': 'from-green-500 to-emerald-600',
      'Senior Lecturer': 'from-orange-500 to-red-600',
      'Lecturer': 'from-cyan-500 to-blue-600',
      'Lab Staff': 'from-slate-500 to-slate-600'
    };
    return colors[designation] || 'from-gray-500 to-gray-600';
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-800">Faculty Management</h1>
          <p className="text-slate-600">Manage faculty members and staff</p>
        </div>
        <div className="flex gap-3">
          <button className="flex items-center gap-2 px-5 py-3 bg-white border-2 border-blue-500 text-blue-600 rounded-xl font-semibold hover:bg-blue-50 transition-all">
            <Upload className="w-5 h-5" />
            Import Faculty
          </button>
          <button className="flex items-center gap-2 px-5 py-3 bg-gradient-to-r from-purple-500 to-pink-600 text-white rounded-xl font-semibold hover:shadow-xl transition-all">
            <Download className="w-5 h-5" />
            Export Data
          </button>
          <button className="flex items-center gap-2 px-5 py-3 bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-xl font-semibold hover:shadow-xl transition-all">
            <Plus className="w-5 h-5" />
            Add Faculty
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid md:grid-cols-4 gap-6">
        <div className="bg-white rounded-2xl shadow-lg p-6 border border-slate-100">
          <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center mb-4">
            <Users className="w-6 h-6 text-white" />
          </div>
          <h3 className="text-slate-600 text-sm font-medium mb-1">Total Faculty</h3>
          <p className="text-3xl font-bold text-slate-800">{faculty.length}</p>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-6 border border-slate-100">
          <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center mb-4">
            <UserCheck className="w-6 h-6 text-white" />
          </div>
          <h3 className="text-slate-600 text-sm font-medium mb-1">Active</h3>
          <p className="text-3xl font-bold text-slate-800">{faculty.filter(f => f.status === 'Active').length}</p>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-6 border border-slate-100">
          <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-600 rounded-xl flex items-center justify-center mb-4">
            <Award className="w-6 h-6 text-white" />
          </div>
          <h3 className="text-slate-600 text-sm font-medium mb-1">Professors</h3>
          <p className="text-3xl font-bold text-slate-800">{faculty.filter(f => f.designation.includes('Professor')).length}</p>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-6 border border-slate-100">
          <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-red-600 rounded-xl flex items-center justify-center mb-4">
            <Users className="w-6 h-6 text-white" />
          </div>
          <h3 className="text-slate-600 text-sm font-medium mb-1">Departments</h3>
          <p className="text-3xl font-bold text-slate-800">{departments.length}</p>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-2xl shadow-lg p-6 border border-slate-200">
        <div className="grid md:grid-cols-4 gap-4">
          <div className="md:col-span-2 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input
              type="text"
              placeholder="Search by name, employee ID, or email..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div className="relative">
            <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
            <select
              value={filterDepartment}
              onChange={(e) => setFilterDepartment(e.target.value)}
              className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">All Departments</option>
              {departments.map(dept => (
                <option key={dept} value={dept}>{dept}</option>
              ))}
            </select>
          </div>
          <div className="relative">
            <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
            <select
              value={filterDesignation}
              onChange={(e) => setFilterDesignation(e.target.value)}
              className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">All Designations</option>
              {designations.map(des => (
                <option key={des} value={des}>{des}</option>
              ))}
            </select>
          </div>
        </div>
        <div className="mt-4 text-sm text-slate-600">
          Showing <strong>{filteredFaculty.length}</strong> of <strong>{faculty.length}</strong> faculty members
        </div>
      </div>

      {/* Faculty Cards */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredFaculty.map((member) => (
          <div key={member.id} className="bg-white rounded-2xl shadow-lg p-6 border border-slate-200 hover:shadow-xl transition-all">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className={`w-14 h-14 bg-gradient-to-br ${getDesignationColor(member.designation)} rounded-xl flex items-center justify-center text-white text-xl font-bold shadow-lg`}>
                  {member.name.split(' ').map(n => n[0]).join('')}
                </div>
                <div>
                  <h3 className="text-lg font-bold text-slate-800">{member.name}</h3>
                  <p className="text-sm text-slate-500">{member.employeeId}</p>
                </div>
              </div>
              <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                member.status === 'Active' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
              }`}>
                {member.status}
              </span>
            </div>

            <div className="space-y-3 mb-4">
              <div className="flex items-center gap-2">
                <Award className="w-4 h-4 text-slate-400" />
                <span className="text-sm text-slate-600">{member.designation}</span>
              </div>
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4 text-slate-400" />
                <span className="text-sm text-slate-600">{member.department}</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-slate-400" />
                <span className="text-sm text-slate-600 truncate">{member.email}</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-slate-400" />
                <span className="text-sm text-slate-600">{member.phone}</span>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-200">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-semibold text-slate-500">Experience</span>
                <span className="text-sm font-bold text-slate-800">{member.experience}</span>
              </div>
              <div className="flex gap-2">
                <button className="flex-1 flex items-center justify-center gap-2 px-3 py-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition-all text-sm font-semibold">
                  <Eye className="w-4 h-4" />
                  View
                </button>
                <button className="flex-1 flex items-center justify-center gap-2 px-3 py-2 bg-green-50 text-green-600 rounded-lg hover:bg-green-100 transition-all text-sm font-semibold">
                  <Edit2 className="w-4 h-4" />
                  Edit
                </button>
                <button
                  onClick={() => handleDeleteFaculty(member.id)}
                  className="px-3 py-2 bg-red-50 text-red-600 rounded-lg hover:bg-red-100 transition-all"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredFaculty.length === 0 && (
        <div className="bg-white rounded-2xl shadow-lg p-12 text-center border border-slate-200">
          <Users className="w-16 h-16 text-slate-300 mx-auto mb-4" />
          <p className="text-slate-500 text-lg">No faculty members found</p>
          <p className="text-slate-400 text-sm">Try adjusting your search or filters</p>
        </div>
      )}
    </div>
  );
}
