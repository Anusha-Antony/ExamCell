import React, { useState } from 'react';
import { MapPin, Users, Calendar, Grid, List, Download, Upload, CheckCircle, AlertCircle, Shuffle } from 'lucide-react';

export default function SeatingArrangement() {
  const [viewMode, setViewMode] = useState('list');
  const [arrangements, setArrangements] = useState([
    {
      id: 1,
      exam: 'Data Structures',
      date: '2026-03-15',
      hall: 'Main Hall A',
      capacity: 60,
      studentsAssigned: 58,
      arrangement: 'Generated',
      pattern: 'Alternate Department'
    },
    {
      id: 2,
      exam: 'Database Management',
      date: '2026-03-18',
      hall: 'Main Hall B',
      capacity: 50,
      studentsAssigned: 48,
      arrangement: 'Generated',
      pattern: 'Roll Number Sequential'
    }
  ]);

  const [showGenerateModal, setShowGenerateModal] = useState(false);
  const [generateForm, setGenerateForm] = useState({
    exam: '',
    hall: '',
    semester: '',
    pattern: 'alternate',
    spacing: '1'
  });

  const halls = [
    { name: 'Main Hall A', capacity: 60, rows: 10, cols: 6 },
    { name: 'Main Hall B', capacity: 50, rows: 10, cols: 5 },
    { name: 'Main Hall C', capacity: 40, rows: 8, cols: 5 },
    { name: 'Lab 1', capacity: 30, rows: 6, cols: 5 }
  ];

  const patterns = [
    { value: 'alternate', label: 'Alternate Department' },
    { value: 'rollnumber', label: 'Roll Number Sequential' },
    { value: 'random', label: 'Random Assignment' },
    { value: 'semester', label: 'Semester Wise' }
  ];

  const handleFormChange = (e) => {
    setGenerateForm({
      ...generateForm,
      [e.target.name]: e.target.value
    });
  };

  const handleGenerateSeating = () => {
    if (!generateForm.exam || !generateForm.hall || !generateForm.semester) {
      alert('Please fill all required fields');
      return;
    }

    const selectedHall = halls.find(h => h.name === generateForm.hall);
    
    const newArrangement = {
      id: Date.now(),
      exam: generateForm.exam,
      date: new Date().toISOString().split('T')[0],
      hall: generateForm.hall,
      capacity: selectedHall.capacity,
      studentsAssigned: Math.floor(selectedHall.capacity * 0.95),
      arrangement: 'Generated',
      pattern: patterns.find(p => p.value === generateForm.pattern).label
    };

    setArrangements([...arrangements, newArrangement]);
    setShowGenerateModal(false);
    setGenerateForm({
      exam: '',
      hall: '',
      semester: '',
      pattern: 'alternate',
      spacing: '1'
    });
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-800">Seating Arrangement</h1>
          <p className="text-slate-600">Manage exam hall seating allocations</p>
        </div>
        <div className="flex gap-3">
          <button className="flex items-center gap-2 px-5 py-3 bg-white border-2 border-blue-500 text-blue-600 rounded-xl font-semibold hover:bg-blue-50 transition-all">
            <Upload className="w-5 h-5" />
            Import Students
          </button>
          <button className="flex items-center gap-2 px-5 py-3 bg-gradient-to-r from-purple-500 to-pink-600 text-white rounded-xl font-semibold hover:shadow-xl transition-all">
            <Download className="w-5 h-5" />
            Export Layout
          </button>
          <button
            onClick={() => setShowGenerateModal(true)}
            className="flex items-center gap-2 px-5 py-3 bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-xl font-semibold hover:shadow-xl transition-all"
          >
            <Shuffle className="w-5 h-5" />
            Generate Seating
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid md:grid-cols-4 gap-6">
        {[
          { title: 'Total Halls', value: halls.length, icon: MapPin, color: 'from-blue-500 to-indigo-600' },
          { title: 'Total Capacity', value: halls.reduce((sum, h) => sum + h.capacity, 0), icon: Users, color: 'from-purple-500 to-pink-600' },
          { title: 'Arrangements', value: arrangements.length, icon: Grid, color: 'from-green-500 to-emerald-600' },
          { title: 'Students Seated', value: arrangements.reduce((sum, a) => sum + a.studentsAssigned, 0), icon: CheckCircle, color: 'from-orange-500 to-red-600' }
        ].map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white rounded-2xl shadow-lg p-6 border border-slate-100">
              <div className={`w-12 h-12 bg-gradient-to-br ${stat.color} rounded-xl flex items-center justify-center mb-4`}>
                <Icon className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-slate-600 text-sm font-medium mb-1">{stat.title}</h3>
              <p className="text-3xl font-bold text-slate-800">{stat.value}</p>
            </div>
          );
        })}
      </div>

      {/* Generate Seating Modal */}
      {showGenerateModal && (
        <div className="bg-white rounded-2xl shadow-lg p-8 border border-slate-200">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold text-slate-800">Generate Seating Arrangement</h3>
            <button
              onClick={() => setShowGenerateModal(false)}
              className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
            >
              <AlertCircle className="w-5 h-5 text-slate-600" />
            </button>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">Exam/Subject *</label>
              <input
                type="text"
                name="exam"
                value={generateForm.exam}
                onChange={handleFormChange}
                placeholder="e.g., Data Structures"
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">Select Hall *</label>
              <select
                name="hall"
                value={generateForm.hall}
                onChange={handleFormChange}
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">Choose Hall</option>
                {halls.map(hall => (
                  <option key={hall.name} value={hall.name}>
                    {hall.name} (Capacity: {hall.capacity})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">Semester *</label>
              <select
                name="semester"
                value={generateForm.semester}
                onChange={handleFormChange}
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">Select Semester</option>
                {['1', '2', '3', '4', '5', '6', '7', '8'].map(sem => (
                  <option key={sem} value={sem}>Semester {sem}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">Seating Pattern *</label>
              <select
                name="pattern"
                value={generateForm.pattern}
                onChange={handleFormChange}
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {patterns.map(pattern => (
                  <option key={pattern.value} value={pattern.value}>{pattern.label}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">Seat Spacing</label>
              <select
                name="spacing"
                value={generateForm.spacing}
                onChange={handleFormChange}
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="1">Leave 1 seat empty</option>
                <option value="2">Leave 2 seats empty</option>
                <option value="0">No spacing</option>
              </select>
            </div>
          </div>

          <div className="mt-8 p-6 bg-blue-50 rounded-xl border border-blue-200">
            <h4 className="text-sm font-bold text-blue-800 mb-3">Pattern Descriptions:</h4>
            <ul className="space-y-2 text-sm text-blue-700">
              <li><strong>Alternate Department:</strong> Students from different departments sit alternately</li>
              <li><strong>Roll Number Sequential:</strong> Students arranged by roll number order</li>
              <li><strong>Random Assignment:</strong> Random seating for maximum security</li>
              <li><strong>Semester Wise:</strong> Students grouped by semester</li>
            </ul>
          </div>

          <div className="mt-6 flex justify-end gap-3">
            <button
              onClick={() => setShowGenerateModal(false)}
              className="px-6 py-3 bg-slate-200 text-slate-700 rounded-xl font-semibold hover:bg-slate-300 transition-all"
            >
              Cancel
            </button>
            <button
              onClick={handleGenerateSeating}
              className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-xl font-semibold hover:shadow-xl transition-all"
            >
              <Shuffle className="w-5 h-5" />
              Generate Arrangement
            </button>
          </div>
        </div>
      )}

      {/* Available Halls */}
      <div className="bg-white rounded-2xl shadow-lg p-6 border border-slate-200">
        <h3 className="text-xl font-bold text-slate-800 mb-6">Available Examination Halls</h3>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
          {halls.map((hall) => (
            <div key={hall.name} className="p-6 bg-slate-50 rounded-xl border-2 border-slate-200 hover:border-blue-300 transition-all">
              <div className="flex items-start justify-between mb-3">
                <MapPin className="w-8 h-8 text-blue-600" />
                <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-semibold">
                  {hall.capacity} seats
                </span>
              </div>
              <h4 className="text-lg font-bold text-slate-800 mb-2">{hall.name}</h4>
              <div className="text-sm text-slate-600">
                <p>Layout: {hall.rows} × {hall.cols}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Seating Arrangements */}
      <div className="bg-white rounded-2xl shadow-lg p-6 border border-slate-200">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-bold text-slate-800">Generated Seating Arrangements</h3>
          <div className="flex gap-2 bg-slate-100 p-1 rounded-lg">
            <button
              onClick={() => setViewMode('list')}
              className={`px-4 py-2 rounded-lg transition-all ${
                viewMode === 'list' ? 'bg-white shadow-sm font-semibold' : 'text-slate-600'
              }`}
            >
              <List className="w-5 h-5" />
            </button>
            <button
              onClick={() => setViewMode('grid')}
              className={`px-4 py-2 rounded-lg transition-all ${
                viewMode === 'grid' ? 'bg-white shadow-sm font-semibold' : 'text-slate-600'
              }`}
            >
              <Grid className="w-5 h-5" />
            </button>
          </div>
        </div>

        {arrangements.length === 0 ? (
          <div className="text-center py-12">
            <Grid className="w-16 h-16 text-slate-300 mx-auto mb-4" />
            <p className="text-slate-500 text-lg">No seating arrangements generated yet</p>
            <p className="text-slate-400 text-sm">Click "Generate Seating" to create a new arrangement</p>
          </div>
        ) : (
          <div className="space-y-4">
            {arrangements.map((arrangement) => (
              <div key={arrangement.id} className="p-6 bg-slate-50 rounded-xl border border-slate-200 hover:border-blue-300 transition-all">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h4 className="text-lg font-bold text-slate-800 mb-2">{arrangement.exam}</h4>
                    <div className="flex items-center gap-3">
                      <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs font-semibold">
                        {arrangement.arrangement}
                      </span>
                      <span className="px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-xs font-semibold">
                        {arrangement.pattern}
                      </span>
                    </div>
                  </div>
                  <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-all">
                    <Download className="w-4 h-4" />
                    Download
                  </button>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                  <div className="flex items-center gap-2 text-slate-600">
                    <Calendar className="w-4 h-4" />
                    {arrangement.date}
                  </div>
                  <div className="flex items-center gap-2 text-slate-600">
                    <MapPin className="w-4 h-4" />
                    {arrangement.hall}
                  </div>
                  <div className="flex items-center gap-2 text-slate-600">
                    <Users className="w-4 h-4" />
                    Capacity: {arrangement.capacity}
                  </div>
                  <div className="flex items-center gap-2 text-slate-600">
                    <CheckCircle className="w-4 h-4" />
                    Assigned: {arrangement.studentsAssigned}
                  </div>
                </div>

                <div className="mt-4 pt-4 border-t border-slate-200">
                  <div className="flex items-center justify-between">
                    <div className="text-sm text-slate-600">
                      <strong>Utilization:</strong> {Math.round((arrangement.studentsAssigned / arrangement.capacity) * 100)}%
                    </div>
                    <div className="w-48 h-2 bg-slate-200 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-gradient-to-r from-blue-500 to-indigo-600"
                        style={{ width: `${(arrangement.studentsAssigned / arrangement.capacity) * 100}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
