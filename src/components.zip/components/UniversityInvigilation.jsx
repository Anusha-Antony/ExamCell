import React, { useState } from 'react';
import { Calendar, Clock, Users, MapPin, Plus, Edit2, Trash2, Save, X, Filter, Search, Download, Upload, FileText } from 'lucide-react';

export default function UniversityExams() {
  const [showAddExam, setShowAddExam] = useState(false);
  const [exams, setExams] = useState([
    {
      id: 1,
      subject: 'Data Structures and Algorithms',
      code: 'CS301',
      semester: '3',
      date: '2026-03-15',
      time: '10:00 AM - 01:00 PM',
      hall: 'Main Hall A',
      students: 150,
      duration: '3 hours',
      status: 'scheduled'
    },
    {
      id: 2,
      subject: 'Database Management Systems',
      code: 'CS302',
      semester: '3',
      date: '2026-03-18',
      time: '02:00 PM - 05:00 PM',
      hall: 'Main Hall B',
      students: 145,
      duration: '3 hours',
      status: 'scheduled'
    },
    {
      id: 3,
      subject: 'Computer Networks',
      code: 'CS401',
      semester: '4',
      date: '2026-03-20',
      time: '10:00 AM - 01:00 PM',
      hall: 'Main Hall C',
      students: 138,
      duration: '3 hours',
      status: 'pending'
    }
  ]);

  const [examForm, setExamForm] = useState({
    subject: '',
    code: '',
    semester: '',
    date: '',
    time: '',
    hall: '',
    students: '',
    duration: ''
  });

  const [filterSemester, setFilterSemester] = useState('');
  const [searchQuery, setSearchQuery] = useState('');

  const semesters = ['1', '2', '3', '4', '5', '6', '7', '8'];
  const timeSlots = [
    '09:00 AM - 12:00 PM',
    '10:00 AM - 01:00 PM',
    '02:00 PM - 05:00 PM'
  ];

  const handleFormChange = (e) => {
    setExamForm({
      ...examForm,
      [e.target.name]: e.target.value
    });
  };

  const handleAddExam = () => {
    if (!examForm.subject || !examForm.code || !examForm.semester || !examForm.date || !examForm.time || !examForm.hall) {
      alert('Please fill all required fields');
      return;
    }

    const newExam = {
      id: Date.now(),
      ...examForm,
      status: 'pending'
    };

    setExams([...exams, newExam]);
    setExamForm({
      subject: '',
      code: '',
      semester: '',
      date: '',
      time: '',
      hall: '',
      students: '',
      duration: ''
    });
    setShowAddExam(false);
  };

  const handleDeleteExam = (id) => {
    if (window.confirm('Are you sure you want to delete this exam?')) {
      setExams(exams.filter(exam => exam.id !== id));
    }
  };

  const filteredExams = exams.filter(exam => {
    const matchesSemester = filterSemester ? exam.semester === filterSemester : true;
    const matchesSearch = searchQuery ? 
      exam.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
      exam.code.toLowerCase().includes(searchQuery.toLowerCase()) : true;
    return matchesSemester && matchesSearch;
  });

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-800">University Exams</h1>
          <p className="text-slate-600">Manage semester end examinations</p>
        </div>
        <div className="flex gap-3">
          <button className="flex items-center gap-2 px-5 py-3 bg-white border-2 border-blue-500 text-blue-600 rounded-xl font-semibold hover:bg-blue-50 transition-all">
            <Upload className="w-5 h-5" />
            Import Timetable
          </button>
          <button className="flex items-center gap-2 px-5 py-3 bg-gradient-to-r from-purple-500 to-pink-600 text-white rounded-xl font-semibold hover:shadow-xl transition-all">
            <Download className="w-5 h-5" />
            Export Schedule
          </button>
          <button
            onClick={() => setShowAddExam(true)}
            className="flex items-center gap-2 px-5 py-3 bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-xl font-semibold hover:shadow-xl transition-all"
          >
            <Plus className="w-5 h-5" />
            Add Exam
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-2xl shadow-lg p-6 border border-slate-200">
        <div className="grid md:grid-cols-3 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input
              type="text"
              placeholder="Search by subject or code..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div className="relative">
            <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
            <select
              value={filterSemester}
              onChange={(e) => setFilterSemester(e.target.value)}
              className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">All Semesters</option>
              {semesters.map(sem => (
                <option key={sem} value={sem}>Semester {sem}</option>
              ))}
            </select>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-sm font-semibold text-slate-700">
              Total Exams: {filteredExams.length}
            </span>
          </div>
        </div>
      </div>

      {/* Add Exam Modal */}
      {showAddExam && (
        <div className="bg-white rounded-2xl shadow-lg p-8 border border-slate-200">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold text-slate-800">Add New University Exam</h3>
            <button
              onClick={() => setShowAddExam(false)}
              className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
            >
              <X className="w-5 h-5 text-slate-600" />
            </button>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">Subject Name *</label>
              <input
                type="text"
                name="subject"
                value={examForm.subject}
                onChange={handleFormChange}
                placeholder="e.g., Data Structures and Algorithms"
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">Subject Code *</label>
              <input
                type="text"
                name="code"
                value={examForm.code}
                onChange={handleFormChange}
                placeholder="e.g., CS301"
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">Semester *</label>
              <select
                name="semester"
                value={examForm.semester}
                onChange={handleFormChange}
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">Select Semester</option>
                {semesters.map(sem => (
                  <option key={sem} value={sem}>Semester {sem}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">Exam Date *</label>
              <input
                type="date"
                name="date"
                value={examForm.date}
                onChange={handleFormChange}
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">Time Slot *</label>
              <select
                name="time"
                value={examForm.time}
                onChange={handleFormChange}
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">Select Time</option>
                {timeSlots.map(slot => (
                  <option key={slot} value={slot}>{slot}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">Examination Hall *</label>
              <input
                type="text"
                name="hall"
                value={examForm.hall}
                onChange={handleFormChange}
                placeholder="e.g., Main Hall A"
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">Number of Students</label>
              <input
                type="number"
                name="students"
                value={examForm.students}
                onChange={handleFormChange}
                placeholder="e.g., 150"
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">Duration</label>
              <input
                type="text"
                name="duration"
                value={examForm.duration}
                onChange={handleFormChange}
                placeholder="e.g., 3 hours"
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          <div className="mt-6 flex justify-end gap-3">
            <button
              onClick={() => setShowAddExam(false)}
              className="px-6 py-3 bg-slate-200 text-slate-700 rounded-xl font-semibold hover:bg-slate-300 transition-all"
            >
              Cancel
            </button>
            <button
              onClick={handleAddExam}
              className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-xl font-semibold hover:shadow-xl transition-all"
            >
              <Save className="w-5 h-5" />
              Add Exam
            </button>
          </div>
        </div>
      )}

      {/* Exams List */}
      <div className="grid gap-6">
        {filteredExams.length === 0 ? (
          <div className="bg-white rounded-2xl shadow-lg p-12 text-center border border-slate-200">
            <Calendar className="w-16 h-16 text-slate-300 mx-auto mb-4" />
            <p className="text-slate-500 text-lg">No exams found</p>
            <p className="text-slate-400 text-sm">Click "Add Exam" to schedule a new university exam</p>
          </div>
        ) : (
          filteredExams.map((exam) => (
            <div key={exam.id} className="bg-white rounded-2xl shadow-lg p-6 border border-slate-200 hover:shadow-xl transition-all">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-xl font-bold text-slate-800">{exam.subject}</h3>
                    <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-semibold">
                      {exam.code}
                    </span>
                    <span className="px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-xs font-semibold">
                      Semester {exam.semester}
                    </span>
                    <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                      exam.status === 'scheduled' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
                    }`}>
                      {exam.status}
                    </span>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button className="p-2 hover:bg-blue-50 text-blue-600 rounded-lg transition-all">
                    <Edit2 className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => handleDeleteExam(exam.id)}
                    className="p-2 hover:bg-red-50 text-red-600 rounded-lg transition-all"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                <div className="flex items-center gap-2 text-sm text-slate-600">
                  <Calendar className="w-4 h-4 text-slate-400" />
                  <span>{exam.date}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-slate-600">
                  <Clock className="w-4 h-4 text-slate-400" />
                  <span>{exam.time}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-slate-600">
                  <MapPin className="w-4 h-4 text-slate-400" />
                  <span>{exam.hall}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-slate-600">
                  <Users className="w-4 h-4 text-slate-400" />
                  <span>{exam.students} students</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-slate-600">
                  <FileText className="w-4 h-4 text-slate-400" />
                  <span>{exam.duration}</span>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
