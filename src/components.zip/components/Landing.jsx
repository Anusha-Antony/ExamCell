import React, { useState, useEffect } from 'react';
import {
  Brain,
  Calendar,
  Users,
  Shield,
  TrendingUp,
  CheckCircle,
  ArrowRight,
  Menu,
  X,
  FileText,
  MapPin,
  Clock,
  BarChart3,
  Database,
  LogIn,
  UserPlus
} from 'lucide-react';

import { useNavigate } from "react-router-dom";

export default function Landing() {
  const navigate = useNavigate();
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeFeature, setActiveFeature] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveFeature((prev) => (prev + 1) % 6);
    }, 3500);
    return () => clearInterval(interval);
  }, []);

  const features = [
    {
      icon: Calendar,
      title: "Intelligent Scheduling",
      description: "Genetic algorithm-based timetable generation with automated conflict detection and optimal resource allocation for seamless exam planning.",
      color: "from-blue-500 to-indigo-600",
      stats: "99% conflict-free"
    },
    {
      icon: MapPin,
      title: "Smart Hall Allocation",
      description: "AI-powered hall and seating arrangement system ensuring optimal space utilization, collision-free allocation, and compliance with capacity constraints.",
      color: "from-indigo-500 to-blue-600",
      stats: "100% optimized"
    },
    {
      icon: Users,
      title: "Duty Assignment",
      description: "Fair and equitable distribution of invigilation duties using advanced optimization algorithms and workload balancing mechanisms.",
      color: "from-blue-600 to-cyan-600",
      stats: "Equal distribution"
    },
    
    {
      icon: Database,
      title: "Centralized Management",
      description: "Unified database system for managing students, faculty, examination halls, and schedules with instant updates and data synchronization.",
      color: "from-blue-500 to-sky-500",
      stats: "Single source of truth"
    },
    {
      icon: BarChart3,
      title: "Advanced Analytics",
      description: "Comprehensive performance metrics, resource utilization reports, and predictive insights for data-driven decision making.",
      color: "from-indigo-600 to-blue-500",
      stats: "Actionable insights"
    }
  ];

  const benefits = [
    { text: "Eliminates manual and paper-based processes", impact: "80% time saved" },
    { text: "Reduces errors in scheduling and allocation", impact: "95% accuracy" },
    { text: "Ensures fair distribution of invigilation duties", impact: "100% balanced" },
    { text: "Centralizes all examination operations", impact: "Single platform" },
    { text: "Increases transparency and accountability", impact: "Full visibility" },
    { text: "Real-time notifications and updates", impact: "Instant alerts" }
  ];

  const stats = [
    { value: "10K+", label: "Exams Managed", icon: FileText },
    { value: "50K+", label: "Students Served", icon: Users },
    { value: "99.9%", label: "System Uptime", icon: TrendingUp },
    { value: "80%", label: "Time Reduction", icon: Clock }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${scrolled ? 'bg-white/95 backdrop-blur-lg shadow-lg' : 'bg-white'}`}>
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="relative">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg">
                  <Brain className="w-7 h-7 text-white" />
                </div>
                <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-cyan-500 rounded-full border-2 border-white animate-pulse"></div>
              </div>
              <div>
                <span className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">InExa</span>
                <p className="text-xs text-slate-500 -mt-1 font-medium">Exam Management System</p>
              </div>
            </div>
            
            {/* Desktop Menu */}
            <div className="hidden md:flex items-center space-x-8">
              <a href="#features" className="text-slate-700 hover:text-blue-600 transition-colors font-medium">Features</a>
              <a href="#benefits" className="text-slate-700 hover:text-blue-600 transition-colors font-medium">Benefits</a>
              <a href="#about" className="text-slate-700 hover:text-blue-600 transition-colors font-medium">About</a>
              <a href="#contact" className="text-slate-700 hover:text-blue-600 transition-colors font-medium">Contact</a>
             <button
  onClick={() => navigate("/Login")}
  className="flex items-center gap-2 px-5 py-2 text-blue-600 hover:text-blue-700 transition-colors font-medium"
            >
              <LogIn className="w-4 h-4" />
              Login
            </button>

            <button
              onClick={() => navigate("/register")}
              className="flex items-center gap-2 px-6 py-2.5 bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-xl font-semibold hover:shadow-xl hover:shadow-blue-500/30 transition-all transform hover:scale-105"
            >
              <UserPlus className="w-4 h-4" />
              Sign Up
            </button>

            </div>

            {/* Mobile Menu Button */}
            <button className="md:hidden text-slate-700" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>

          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden mt-4 pb-4 space-y-4 border-t pt-4">
              <a href="#features" className="block text-slate-700 hover:text-blue-600 transition-colors font-medium">Features</a>
              <a href="#benefits" className="block text-slate-700 hover:text-blue-600 transition-colors font-medium">Benefits</a>
              <a href="#about" className="block text-slate-700 hover:text-blue-600 transition-colors font-medium">About</a>
              <a href="#contact" className="block text-slate-700 hover:text-blue-600 transition-colors font-medium">Contact</a>
              <button className="w-full flex items-center justify-center gap-2 px-5 py-2 text-blue-600 border border-blue-200 rounded-xl hover:bg-blue-50 transition-colors font-medium">
                <LogIn className="w-4 h-4" />
                Login
              </button>
              <button className="w-full flex items-center justify-center gap-2 px-6 py-2.5 bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-xl font-semibold">
                <UserPlus className="w-4 h-4" />
                Sign Up
              </button>
            </div>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-24 px-6 overflow-hidden">
        {/* Animated Background */}
        <div className="absolute inset-0 -z-10">
          <div className="absolute inset-0 bg-gradient-to-br from-blue-50 via-indigo-50 to-cyan-50"></div>
          <div className="absolute top-20 left-10 w-96 h-96 bg-blue-300/30 rounded-full mix-blend-multiply filter blur-3xl animate-pulse"></div>
          <div className="absolute top-40 right-10 w-96 h-96 bg-indigo-300/30 rounded-full mix-blend-multiply filter blur-3xl animate-pulse" style={{ animationDelay: '1s' }}></div>
          <div className="absolute bottom-20 left-1/2 w-96 h-96 bg-cyan-300/30 rounded-full mix-blend-multiply filter blur-3xl animate-pulse" style={{ animationDelay: '2s' }}></div>
          
          {/* Grid Pattern */}
          <div className="absolute inset-0 opacity-[0.03]" style={{
            backgroundImage: `linear-gradient(to right, rgb(59 130 246) 1px, transparent 1px),
                             linear-gradient(to bottom, rgb(59 130 246) 1px, transparent 1px)`,
            backgroundSize: '40px 40px'
          }}></div>
        </div>

        <div className="max-w-7xl mx-auto relative z-10">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 px-5 py-2.5 bg-white/80 backdrop-blur-sm border border-blue-200 rounded-full text-blue-700 text-sm font-semibold mb-8 shadow-lg">
              <Shield className="w-4 h-4" />
              <span>Designed for our Institution's Success</span>
            </div>
            
            <h1 className="text-6xl md:text-8xl font-bold mb-8 leading-tight">
              <span className="bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                InExa
              </span>
              <br />
              <span className="text-slate-800 text-5xl md:text-6xl">AI-Enhanced Exam Cell</span>
              <br />
              <span className="text-slate-600 text-4xl md:text-5xl font-semibold">Management System</span>
            </h1>
            
            <p className="text-xl md:text-2xl text-slate-600 max-w-4xl mx-auto mb-12 leading-relaxed font-light">
              Streamline our institution's examination processes with intelligent automation, AI-powered monitoring, and comprehensive resource optimization.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-5 justify-center mb-16">
              <button className="group px-12 py-5 bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-xl font-semibold text-lg hover:shadow-2xl hover:shadow-blue-500/40 transition-all transform hover:scale-105 flex items-center justify-center gap-3">
                Get Started
                <ArrowRight className="w-6 h-6 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-6xl mx-auto">
              {stats.map((stat, index) => {
                const Icon = stat.icon;
                return (
                  <div key={index} className="group p-6 bg-white/80 backdrop-blur-sm rounded-2xl shadow-xl border border-blue-100 hover:border-blue-300 hover:shadow-2xl transition-all">
                    <Icon className="w-8 h-8 text-blue-600 mb-3 mx-auto group-hover:scale-110 transition-transform" />
                    <div className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent mb-2">
                      {stat.value}
                    </div>
                    <div className="text-slate-600 font-semibold text-sm">{stat.label}</div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section id="benefits" className="py-24 px-6 bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900 text-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <div className="inline-block px-4 py-2 bg-blue-500/20 border border-blue-400/30 text-blue-300 rounded-full text-sm font-semibold mb-6">
              Why Choose InExa
            </div>
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Transform our Institution's
              <span className="block text-blue-400 mt-2">Examination Management</span>
            </h2>
            <p className="text-slate-300 text-lg max-w-3xl mx-auto leading-relaxed">
              Experience complete automation and efficiency with our comprehensive solution designed specifically for educational institutions.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {benefits.map((benefit, idx) => (
              <div key={idx} className="group p-8 bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 hover:border-blue-400/40 transition-all hover:bg-white/10">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5 group-hover:scale-110 transition-transform shadow-lg">
                    <CheckCircle className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <p className="text-white font-medium mb-2 text-lg">{benefit.text}</p>
                    <p className="text-blue-300 text-sm font-semibold">{benefit.impact}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-24 px-6 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <div className="inline-block px-4 py-2 bg-blue-100 text-blue-700 rounded-full text-sm font-semibold mb-6">
              Powerful Capabilities
            </div>
            <h2 className="text-4xl md:text-6xl font-bold mb-6">
              <span className="bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                Comprehensive Features
              </span>
              <br />
              <span className="text-slate-800">for our Institution</span>
            </h2>
            <p className="text-slate-600 text-xl max-w-3xl mx-auto">
              Advanced algorithms and AI technology working together for seamless examination management
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              const isActive = activeFeature === index;
              return (
                <div
                  key={index}
                  className={`group p-8 bg-gradient-to-br from-slate-50 to-white rounded-2xl border-2 transition-all duration-500 ${
                    isActive ? 'border-blue-500 shadow-2xl shadow-blue-500/20 scale-105' : 'border-slate-200 hover:border-blue-300 hover:shadow-xl'
                  }`}
                  onMouseEnter={() => setActiveFeature(index)}
                >
                  <div className={`w-16 h-16 bg-gradient-to-br ${feature.color} rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300 shadow-xl`}>
                    <Icon className="w-8 h-8 text-white" />
                  </div>
                  <div className="mb-3">
                    <h3 className="text-2xl font-bold text-slate-800 mb-2">{feature.title}</h3>
                    <span className="text-xs font-semibold text-blue-600 bg-blue-50 px-3 py-1 rounded-full">
                      {feature.stats}
                    </span>
                  </div>
                  <p className="text-slate-600 leading-relaxed">{feature.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-24 px-6 bg-gradient-to-br from-slate-50 to-blue-50">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <div>
              <div className="inline-block px-4 py-2 bg-blue-100 text-blue-700 rounded-full text-sm font-semibold mb-6">
                About InExa
              </div>
              <h2 className="text-4xl md:text-5xl font-bold mb-6 text-slate-800">
                Built Specifically for
                <span className="block bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent mt-2">
                  Educational Excellence
                </span>
              </h2>
              <p className="text-slate-600 text-lg leading-relaxed mb-6">
                InExa is a comprehensive AI-enhanced examination management system developed to address the unique challenges faced by educational institutions in managing examinations efficiently.
              </p>
              <p className="text-slate-600 text-lg leading-relaxed mb-6">
                Our platform combines cutting-edge artificial intelligence with practical examination management needs, ensuring our institution operates at peak efficiency while maintaining the highest standards of academic integrity.
              </p>
              <div className="space-y-4">
                {[
                  "Designed for institutional workflows",
                  "Scalable for any institution size",
                  "Secure and reliable infrastructure",
                  "Continuous updates and support"
                ].map((item, idx) => (
                  <div key={idx} className="flex items-center gap-3">
                    <div className="w-6 h-6 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center flex-shrink-0">
                      <CheckCircle className="w-4 h-4 text-white" />
                    </div>
                    <p className="text-slate-700 font-medium">{item}</p>
                  </div>
                ))}
              </div>
            </div>
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-indigo-500/20 rounded-3xl blur-2xl"></div>
              <div className="relative bg-gradient-to-br from-blue-500 to-indigo-600 p-12 rounded-3xl shadow-2xl text-white">
                <h3 className="text-3xl font-bold mb-8">Key Capabilities</h3>
                <div className="space-y-6">
                  {[
                    { icon: Calendar, text: "Automated exam scheduling" },
                    { icon: MapPin, text: "Intelligent hall allocation" },
                    { icon: Users, text: "Fair duty distribution" },
                    { icon: BarChart3, text: "Real-time analytics" },
                    { icon: Shield, text: "Secure data management" }
                  ].map((item, idx) => {
                    const Icon = item.icon;
                    return (
                      <div key={idx} className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center flex-shrink-0">
                          <Icon className="w-6 h-6 text-white" />
                        </div>
                        <p className="text-lg font-medium">{item.text}</p>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 px-6 bg-gradient-to-br from-blue-500 via-indigo-500 to-blue-600 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-0 w-96 h-96 bg-white rounded-full blur-3xl"></div>
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-white rounded-full blur-3xl"></div>
        </div>
        
        <div className="max-w-5xl mx-auto text-center relative z-10">
          <h2 className="text-4xl md:text-6xl font-bold mb-6 text-white">
            Ready to Modernize our
            <br />Examination Management?
          </h2>
          <p className="text-xl md:text-2xl text-blue-50 mb-12 max-w-3xl mx-auto">
            Join our institution in revolutionizing exam processes with InExa's intelligent automation platform
          </p>
          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <button className="group px-12 py-5 bg-white text-blue-600 rounded-xl font-bold text-lg hover:shadow-2xl transition-all transform hover:scale-105 flex items-center justify-center gap-3">
              Get Started Now
              <ArrowRight className="w-6 h-6 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer id="contact" className="py-16 px-6 bg-slate-900 text-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-12 mb-12">
            <div className="md:col-span-2">
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center">
                  <Brain className="w-7 h-7 text-white" />
                </div>
                <div>
                  <span className="text-2xl font-bold">InExa</span>
                  <p className="text-xs text-slate-400">Exam Management System</p>
                </div>
              </div>
              <p className="text-slate-400 leading-relaxed max-w-md">
                Empowering educational institutions with intelligent examination management solutions for a more efficient and transparent academic environment.
              </p>
            </div>
            
            <div>
              <h4 className="font-bold mb-4 text-lg">Quick Links</h4>
              <ul className="space-y-3 text-slate-400">
                <li><a href="#features" className="hover:text-blue-400 transition-colors">Features</a></li>
                <li><a href="#benefits" className="hover:text-blue-400 transition-colors">Benefits</a></li>
                <li><a href="#about" className="hover:text-blue-400 transition-colors">About</a></li>
                <li><a href="#document" className="hover:text-blue-400 transition-colors">Documentation</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-bold mb-4 text-lg">Support</h4>
              <ul className="space-y-3 text-slate-400">
                <li><a href="/help" className="hover:text-blue-400 transition-colors">Help Center</a></li>
                <li><a href="/contact" className="hover:text-blue-400 transition-colors">Contact Us</a></li>
                <li><a href="/faqs" className="hover:text-blue-400 transition-colors">FAQs</a></li>
                <li><a href="/privacy" className="hover:text-blue-400 transition-colors">Privacy Policy</a></li>
              </ul>
            </div>
          </div>
          
          <div className="pt-8 border-t border-slate-800 text-center text-slate-400">
            <p>&copy; 2026 InExa. Transforming examination management for educational institutions.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
