import { useState } from "react";

/* ─── DATA ─── */
const teacher = {
  name: "Dr. Sarah Johnson",
  id: "TCH-2024-101",
  department: "Computer Science",
  avatar: "SJ",
  designation: "Senior Lecturer",
  email: "sarah.johnson@university.edu",
  phone: "+91 98765 43210",
  specialization: "Artificial Intelligence & Machine Learning",
  experience: "8 Years",
  joined: "March 2018",
  totalExams: 24,
  completedExams: 19,
  status: "Active",
};

const duties = [
  { id: 1, exam: "Computer Networks Final", class: "CS-3A", room: "Room 201", date: "2026-02-06", time: "09:00 AM – 12:00 PM", subject: "CS301", students: 45, status: "Upcoming" },
  { id: 2, exam: "Database Mgmt Midterm", class: "CS-2B", room: "Room 105", date: "2026-02-08", time: "02:00 PM – 04:00 PM", subject: "CS202", students: 38, status: "Upcoming" },
  { id: 3, exam: "Data Structures Final", class: "CS-2A", room: "Hall A", date: "2026-02-04", time: "09:00 AM – 12:00 PM", subject: "CS201", students: 52, status: "Completed" },
  { id: 4, exam: "Operating Systems Quiz", class: "CS-3B", room: "Room 303", date: "2026-02-12", time: "11:00 AM – 12:30 PM", subject: "CS302", students: 41, status: "Upcoming" },
];

const adjustments = [
  { id: 1, absentTeacher: "Dr. Mark Evans", replacedBy: "Dr. Sarah Johnson", exam: "Physics Mechanics Midterm", class: "PHY-2A", room: "Room 401", originalDate: "2026-02-07", time: "10:00 AM – 12:00 PM", reason: "Medical Leave", status: "Confirmed" },
  { id: 2, absentTeacher: "Prof. Aisha Rao", replacedBy: "Dr. Sarah Johnson", exam: "Linear Algebra Quiz", class: "MATH-3B", room: "Room 202", originalDate: "2026-02-09", time: "02:00 PM – 03:30 PM", reason: "Personal Leave", status: "Pending" },
  { id: 3, absentTeacher: "Dr. Liam Carter", replacedBy: "Dr. Emily Woods", exam: "Organic Chemistry Final", class: "CHM-2A", room: "Lab Hall B", originalDate: "2026-02-05", time: "09:00 AM – 12:00 PM", reason: "Family Leave", status: "Confirmed" },
  { id: 4, absentTeacher: "Dr. Sarah Johnson", replacedBy: "Prof. Aisha Rao", exam: "Computer Networks Final", class: "CS-3A", room: "Room 201", originalDate: "2026-02-06", time: "09:00 AM – 12:00 PM", reason: "Training Leave", status: "Confirmed" },
];

const statusLight = {
  Upcoming:  { bg: "#fff7ed", text: "#ea580c", border: "#fdba74" },
  Completed: { bg: "#ecfdf5", text: "#5da1f4", border: "#6eb5e7" },
  Confirmed: { bg: "#ecfdf5", text: "#059669", border: "rgb(59 130 246) " },
  Pending:   { bg: "#fffbeb", text: "#d97706", border: "#fcd34d" },
};

const navItems = [
  { id: "profile", label: "My Profile", icon: "👤" },
  { id: "duties", label: "Invigilation Duties", icon: "📋" },
  { id: "adjustments", label: "Leave Adjustments", icon: "🔄" },
];

/* ─── COMPONENT ─── */
export default function TeachersPage() {
  const [activeNav, setActiveNav] = useState("duties");
  const [activeFilter, setActiveFilter] = useState("All");

  const fmt = (d) => new Date(d).toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" });

  const Pills = ({ duty }) => (
    <div style={{ display: "flex", flexWrap: "wrap", gap: "8px" }}>
      {[
        { icon: "🎓", label: "Class",    value: duty.class,                            accent: "#0d9488", bg: "#f0fdfa" },
        { icon: "📍", label: "Room",     value: duty.room,                             accent: "#d97706", bg: "#fffbeb" },
        { icon: "📅", label: "Date",     value: fmt(duty.date || duty.originalDate),   accent: "#db2777", bg: "#fdf2f8" },
        { icon: "🕐", label: "Time",     value: duty.time,                             accent: "#0891b2", bg: "#f0f9ff" },
        { icon: "👥", label: "Students", value: duty.students,                         accent: "#7c3aed", bg: "#f5f3ff" },
      ].map((p, i) => (
        <div key={i} style={{
          display: "flex", alignItems: "center", gap: "7px", padding: "7px 11px",
          borderRadius: "8px", background: p.bg, border: `1px solid ${p.accent}30`,
        }}>
          <span style={{ fontSize: "13px" }}>{p.icon}</span>
          <div>
            <div style={{ fontSize: "9px", color: "#9ca3af", textTransform: "uppercase", letterSpacing: "0.6px", fontWeight: "600" }}>{p.label}</div>
            <div style={{ fontSize: "12px", fontWeight: "600", color: "#1e293b" }}>{p.value}</div>
          </div>
        </div>
      ))}
    </div>
  );

  return (
    <div style={{ display: "flex", minHeight: "100vh", fontFamily: "'Segoe UI', system-ui, sans-serif", background: "#f1f5f9" }}>

      {/* ════════════ SIDEBAR ════════════ */}
      <aside style={{
        width: "280px", flexShrink: 0, position: "sticky", top: 0, height: "100vh",
        background: "linear-gradient(180deg, rgb(59 130 246)  0%, rgb(45, 105, 203)  50%, rgb(28, 94, 201)  100%)",
        borderRight: "1px solid rgba(20,184,166,0.15)",
        display: "flex", flexDirection: "column",
        boxShadow: "4px 0 20px rgba(0,0,0,0.08)",
      }}>
        {/* Logo Header */}
        <div style={{ padding: "24px 20px", borderBottom: "1px solid rgba(20,184,166,0.15)" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
            <div style={{
              width: "44px", height: "44px", borderRadius: "12px",
              background: "linear-gradient(135deg, rgb(59 130 246) , rgb(59 130 246) )",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: "20px", boxShadow: "0 4px 16px rgba(20,184,166,0.4)",
            }}>📚</div>
            <div>
              <div style={{ fontSize: "17px", fontWeight: "700", color: "#fff", letterSpacing: "-0.5px" }}>ExamCell</div>
              <div style={{ fontSize: "10px", color: "rgba(255,255,255,0.5)", textTransform: "uppercase", letterSpacing: "1.2px", fontWeight: "600" }}>Teacher Portal</div>
            </div>
          </div>
        </div>

        {/* Teacher Profile Card - Clickable */}
        <div 
          onClick={() => setActiveNav("profile")}
          style={{ 
            padding: "20px 18px", 
            borderBottom: "1px solid rgba(20,184,166,0.15)",
            cursor: "pointer",
            transition: "all 0.2s",
            background: activeNav === "profile" ? "rgba(20,184,166,0.12)" : "transparent",
          }}
          onMouseEnter={(e) => { if (activeNav !== "profile") e.currentTarget.style.background = "rgba(255,255,255,0.05)"; }}
          onMouseLeave={(e) => { if (activeNav !== "profile") e.currentTarget.style.background = "transparent"; }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: "14px" }}>
            {/* Avatar with online indicator */}
            <div style={{ position: "relative", flexShrink: 0 }}>
              <div style={{
                width: "56px", height: "56px", borderRadius: "50%",
                background: "linear-gradient(135deg, #14b8a6, #5eead4)",
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: "20px", fontWeight: "700", color: "#fff",
                boxShadow: "0 0 0 3px #134e4a, 0 0 0 5px #14b8a6",
              }}>{teacher.avatar}</div>
              <div style={{
                position: "absolute", bottom: "0", right: "0",
                width: "14px", height: "14px", borderRadius: "50%",
                background: "#22c55e", border: "2px solid #134e4a",
                boxShadow: "0 0 6px rgba(34,197,94,0.6)",
              }}></div>
            </div>

            {/* Teacher Info */}
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: "15px", fontWeight: "700", color: "#fff", letterSpacing: "-0.3px", marginBottom: "2px" }}>{teacher.name}</div>
              <div style={{ fontSize: "11px", color: "#5eead4", fontWeight: "600", marginBottom: "4px" }}>{teacher.designation}</div>
              <div style={{
                display: "inline-block",
                padding: "2px 8px", borderRadius: "12px",
                background: "rgba(20,184,166,0.2)", border: "1px solid rgba(20,184,166,0.4)",
                fontSize: "9px", fontWeight: "700", color: "rgba(255,255,255,0.8)",
                letterSpacing: "0.5px", textTransform: "uppercase",
              }}>ID: {teacher.id}</div>
            </div>

            {/* Click indicator */}
            {activeNav === "profile" && (
              <div style={{ 
                width: "8px", height: "8px", borderRadius: "50%", 
                background: "#14b8a6", boxShadow: "0 0 8px #14b8a6",
                flexShrink: 0,
              }}></div>
            )}
          </div>
        </div>

        {/* Navigation Links */}
        <nav style={{ flex: 1, padding: "12px", overflowY: "auto" }}>
          <div style={{ fontSize: "10px", color: "rgba(255,255,255,0.4)", textTransform: "uppercase", letterSpacing: "1px", fontWeight: "700", padding: "8px 12px", marginBottom: "4px" }}>Navigation</div>
          {navItems.map((item) => {
            const active = activeNav === item.id;
            return (
              <button key={item.id} onClick={() => setActiveNav(item.id)} style={{
                width: "100%", display: "flex", alignItems: "center", gap: "12px",
                padding: "12px 14px", borderRadius: "10px", border: "none", cursor: "pointer",
                marginBottom: "4px", textAlign: "left", transition: "all 0.2s",
                background: active ? "linear-gradient(135deg, rgba(20,184,166,0.25), rgba(13,148,136,0.15))" : "transparent",
                color: active ? "#5eead4" : "rgba(255,255,255,0.5)",
                boxShadow: active ? "0 0 0 1px rgba(20,184,166,0.3)" : "none",
                fontWeight: active ? "600" : "500",
              }}
                onMouseEnter={(e) => { if (!active) { e.currentTarget.style.background = "rgba(255,255,255,0.06)"; e.currentTarget.style.color = "rgba(255,255,255,0.8)"; }}}
                onMouseLeave={(e) => { if (!active) { e.currentTarget.style.background = "transparent"; e.currentTarget.style.color = "rgba(255,255,255,0.5)"; }}}
              >
                <span style={{ fontSize: "17px", width: "20px", textAlign: "center" }}>{item.icon}</span>
                <span style={{ fontSize: "13px" }}>{item.label}</span>
                {active && <div style={{ marginLeft: "auto", width: "6px", height: "6px", borderRadius: "50%", background: "#14b8a6", boxShadow: "0 0 8px #14b8a6" }}></div>}
              </button>
            );
          })}
        </nav>

        {/* Footer Stats */}
        <div style={{ padding: "16px 18px", borderTop: "1px solid rgba(20,184,166,0.15)" }}>
          <div style={{ fontSize: "10px", color: "rgba(255,255,255,0.4)", textTransform: "uppercase", letterSpacing: "0.8px", fontWeight: "700", marginBottom: "10px" }}>Quick Stats</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px" }}>
            <div style={{ padding: "10px", borderRadius: "8px", background: "rgba(20,184,166,0.1)", border: "1px solid rgba(20,184,166,0.2)" }}>
              <div style={{ fontSize: "20px", fontWeight: "700", color: "#5eead4", marginBottom: "2px" }}>{duties.filter(d => d.status === "Upcoming").length}</div>
              <div style={{ fontSize: "9px", color: "rgba(255,255,255,0.5)", textTransform: "uppercase", letterSpacing: "0.5px" }}>Upcoming</div>
            </div>
            <div style={{ padding: "10px", borderRadius: "8px", background: "rgba(20,184,166,0.1)", border: "1px solid rgba(20,184,166,0.2)" }}>
              <div style={{ fontSize: "20px", fontWeight: "700", color: "#5eead4", marginBottom: "2px" }}>{duties.filter(d => d.status === "Completed").length}</div>
              <div style={{ fontSize: "9px", color: "rgba(255,255,255,0.5)", textTransform: "uppercase", letterSpacing: "0.5px" }}>Completed</div>
            </div>
          </div>
        </div>
      </aside>

      {/* ════════════ MAIN CONTENT ════════════ */}
      <main style={{ flex: 1, overflowY: "auto", padding: "32px 40px", minWidth: 0 }}>

        {/* ─── PROFILE PAGE ─── */}
        {activeNav === "profile" && (
          <div>
            {/* Page Header */}
            <div style={{ marginBottom: "28px" }}>
              <h1 style={{ margin: 0, fontSize: "26px", fontWeight: "700", color: "#1e293b", letterSpacing: "-0.5px" }}>👤 Teacher Profile</h1>
              <p style={{ margin: "6px 0 0", fontSize: "14px", color: "#94a3b8" }}>Complete details about your profile and performance</p>
            </div>

            {/* Main Profile Card */}
            <div style={{ background: "#fff", borderRadius: "16px", overflow: "hidden", boxShadow: "0 2px 8px rgba(0,0,0,0.08)", marginBottom: "24px" }}>
              {/* Header Banner */}
              <div style={{ 
                height: "120px", 
                background: "linear-gradient(135deg, #134e4a 0%, #0d9488 50%, #14b8a6 100%)",
                position: "relative",
              }}>
                <div style={{ position: "absolute", bottom: "-50px", left: "32px" }}>
                  <div style={{
                    width: "100px", height: "100px", borderRadius: "50%",
                    background: "linear-gradient(135deg, #14b8a6, #5eead4)",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    fontSize: "36px", fontWeight: "700", color: "#fff",
                    boxShadow: "0 0 0 6px #fff, 0 4px 20px rgba(0,0,0,0.15)",
                  }}>{teacher.avatar}</div>
                </div>
              </div>

              {/* Profile Content */}
              <div style={{ padding: "60px 32px 32px" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "start", marginBottom: "24px" }}>
                  <div>
                    <h2 style={{ margin: 0, fontSize: "24px", fontWeight: "700", color: "#1e293b", marginBottom: "6px" }}>{teacher.name}</h2>
                    <p style={{ margin: 0, fontSize: "15px", color: "#0d9488", fontWeight: "600", marginBottom: "8px" }}>{teacher.designation}</p>
                    <div style={{ display: "flex", gap: "10px", flexWrap: "wrap" }}>
                      <span style={{ 
                        padding: "4px 12px", borderRadius: "20px", 
                        background: "#eef9f7", border: "1px solid #a7f3d0",
                        fontSize: "11px", fontWeight: "700", color: "#0d9488",
                        textTransform: "uppercase", letterSpacing: "0.5px"
                      }}>{teacher.id}</span>
                      <span style={{ 
                        padding: "4px 12px", borderRadius: "20px", 
                        background: "#ecfdf5", border: "1px solid #6ee7b7",
                        fontSize: "11px", fontWeight: "700", color: "#059669",
                        textTransform: "uppercase", letterSpacing: "0.5px"
                      }}>● {teacher.status}</span>
                    </div>
                  </div>
                </div>

                {/* Info Grid */}
                <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: "20px", marginBottom: "28px" }}>
                  {[
                    { icon: "✉️", label: "Email", value: teacher.email, color: "#0891b2" },
                    { icon: "📞", label: "Phone", value: teacher.phone, color: "#0d9488" },
                    { icon: "🏛️", label: "Department", value: teacher.department, color: "#7c3aed" },
                    { icon: "🎯", label: "Specialization", value: teacher.specialization, color: "#db2777" },
                    { icon: "📅", label: "Experience", value: teacher.experience, color: "#ea580c" },
                    { icon: "🗓️", label: "Joined", value: teacher.joined, color: "#059669" },
                  ].map((item, i) => (
                    <div key={i} style={{
                      padding: "16px 18px", borderRadius: "12px",
                      background: "#f8fafc", border: "1px solid #e2e8f0",
                      display: "flex", alignItems: "center", gap: "12px",
                      transition: "all 0.2s",
                    }}
                      onMouseEnter={(e) => { e.currentTarget.style.borderColor = item.color + "50"; e.currentTarget.style.boxShadow = `0 2px 10px ${item.color}15`; }}
                      onMouseLeave={(e) => { e.currentTarget.style.borderColor = "#e2e8f0"; e.currentTarget.style.boxShadow = "none"; }}
                    >
                      <div style={{ 
                        width: "40px", height: "40px", borderRadius: "10px",
                        background: item.color + "10", border: `1px solid ${item.color}30`,
                        display: "flex", alignItems: "center", justifyContent: "center",
                        fontSize: "18px", flexShrink: 0,
                      }}>{item.icon}</div>
                      <div style={{ minWidth: 0 }}>
                        <div style={{ fontSize: "10px", color: "#94a3b8", textTransform: "uppercase", letterSpacing: "0.6px", fontWeight: "600", marginBottom: "3px" }}>{item.label}</div>
                        <div style={{ fontSize: "13px", fontWeight: "600", color: "#1e293b", wordBreak: "break-all" }}>{item.value}</div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Performance Stats */}
                <div style={{ padding: "20px", borderRadius: "12px", background: "linear-gradient(135deg, #eef9f7, #f0fdfa)", border: "1px solid #a7f3d0" }}>
                  <h3 style={{ margin: "0 0 16px", fontSize: "15px", fontWeight: "700", color: "#0d9488" }}>📊 Examination Performance</h3>
                  <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "16px" }}>
                    <div style={{ textAlign: "center" }}>
                      <div style={{ fontSize: "28px", fontWeight: "700", color: "#0d9488", marginBottom: "4px" }}>{teacher.totalExams}</div>
                      <div style={{ fontSize: "11px", color: "#64748b", textTransform: "uppercase", letterSpacing: "0.5px" }}>Total Exams</div>
                    </div>
                    <div style={{ textAlign: "center" }}>
                      <div style={{ fontSize: "28px", fontWeight: "700", color: "#059669", marginBottom: "4px" }}>{teacher.completedExams}</div>
                      <div style={{ fontSize: "11px", color: "#64748b", textTransform: "uppercase", letterSpacing: "0.5px" }}>Completed</div>
                    </div>
                    <div style={{ textAlign: "center" }}>
                      <div style={{ fontSize: "28px", fontWeight: "700", color: "#ea580c", marginBottom: "4px" }}>{teacher.totalExams - teacher.completedExams}</div>
                      <div style={{ fontSize: "11px", color: "#64748b", textTransform: "uppercase", letterSpacing: "0.5px" }}>Pending</div>
                    </div>
                  </div>
                  
                  {/* Progress Bar */}
                  <div style={{ marginTop: "16px" }}>
                    <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "8px" }}>
                      <span style={{ fontSize: "11px", color: "#64748b", fontWeight: "600" }}>Completion Rate</span>
                      <span style={{ fontSize: "11px", color: "#0d9488", fontWeight: "700" }}>{Math.round((teacher.completedExams / teacher.totalExams) * 100)}%</span>
                    </div>
                    <div style={{ width: "100%", height: "8px", background: "#d1fae5", borderRadius: "4px", overflow: "hidden" }}>
                      <div style={{
                        width: `${(teacher.completedExams / teacher.totalExams) * 100}%`,
                        height: "100%", borderRadius: "4px",
                        background: "linear-gradient(90deg, #14b8a6, #059669)",
                        transition: "width 0.6s ease",
                      }}></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ─── INVIGILATION DUTIES PAGE ─── */}
        {activeNav === "duties" && (
          <div>
            {/* Page Header */}
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "28px" }}>
              <div>
                <h1 style={{ margin: 0, fontSize: "26px", fontWeight: "700", color: "#1e293b", letterSpacing: "-0.5px" }}>📋 Invigilation Duties</h1>
                <p style={{ margin: "6px 0 0", fontSize: "14px", color: "#94a3b8" }}>All your scheduled exam invigilation duties</p>
              </div>
              <div style={{ 
                padding: "8px 16px", borderRadius: "10px", 
                background: "#eef9f7", border: "1px solid #a7f3d0", 
                fontSize: "13px", color: "#0d9488", fontWeight: "600",
                boxShadow: "0 2px 6px rgba(13,148,136,0.1)",
              }}>
                🔔 {duties.filter((d) => d.status === "Upcoming").length} Upcoming Duties
              </div>
            </div>

            {/* Stats Cards */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "18px", marginBottom: "28px" }}>
              {[
                { label: "Total Duties",  value: duties.length,                                          icon: "📋", accent: "#0d9488", bg: "#eef9f7" },
                { label: "Upcoming",      value: duties.filter((d) => d.status === "Upcoming").length,   icon: "⏳", accent: "#ea580c", bg: "#fff7ed" },
                { label: "Completed",     value: duties.filter((d) => d.status === "Completed").length,  icon: "✅", accent: "#059669", bg: "#ecfdf5" },
              ].map((s, i) => (
                <div key={i} style={{
                  background: "#fff", borderRadius: "14px", padding: "20px",
                  border: "1px solid #e2e8f0", display: "flex", alignItems: "center", gap: "16px",
                  boxShadow: "0 2px 6px rgba(0,0,0,0.06)", transition: "all 0.2s",
                }}
                  onMouseEnter={(e) => { e.currentTarget.style.borderColor = s.accent + "50"; e.currentTarget.style.boxShadow = `0 4px 14px ${s.accent}18`; }}
                  onMouseLeave={(e) => { e.currentTarget.style.borderColor = "#e2e8f0"; e.currentTarget.style.boxShadow = "0 2px 6px rgba(0,0,0,0.06)"; }}
                >
                  <div style={{ 
                    width: "52px", height: "52px", borderRadius: "12px", 
                    background: s.bg, border: `1px solid ${s.accent}30`, 
                    display: "flex", alignItems: "center", justifyContent: "center", 
                    fontSize: "22px", flexShrink: 0,
                  }}>{s.icon}</div>
                  <div>
                    <div style={{ fontSize: "28px", fontWeight: "700", color: "#1e293b", lineHeight: "1" }}>{s.value}</div>
                    <div style={{ fontSize: "12px", color: "#94a3b8", marginTop: "4px" }}>{s.label}</div>
                  </div>
                </div>
              ))}
            </div>

            {/* Duties List */}
            <div style={{ display: "grid", gap: "14px" }}>
              {duties.map((d) => {
                const ss = statusLight[d.status];
                return (
                  <div key={d.id} style={{
                    background: "#fff", borderRadius: "14px",
                    border: "1px solid #e2e8f0", overflow: "hidden", transition: "all 0.22s",
                    boxShadow: "0 2px 6px rgba(0,0,0,0.06)",
                  }}
                    onMouseEnter={(e) => { e.currentTarget.style.borderColor = "#0d9488"; e.currentTarget.style.boxShadow = "0 6px 16px rgba(13,148,136,0.18)"; e.currentTarget.style.transform = "translateY(-2px)"; }}
                    onMouseLeave={(e) => { e.currentTarget.style.borderColor = "#e2e8f0"; e.currentTarget.style.boxShadow = "0 2px 6px rgba(0,0,0,0.06)"; e.currentTarget.style.transform = "translateY(0)"; }}
                  >
                    <div style={{ height: "4px", background: d.status === "Upcoming" ? "linear-gradient(90deg,#14b8a6,#5eead4)" : "linear-gradient(90deg,#34d399,#6ee7b7)" }}></div>
                    <div style={{ padding: "20px 22px" }}>
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "16px" }}>
                        <div>
                          <div style={{ fontSize: "16px", fontWeight: "700", color: "#1e293b", marginBottom: "4px" }}>{d.exam}</div>
                          <div style={{ fontSize: "12px", color: "#94a3b8", fontWeight: "500" }}>{d.subject}</div>
                        </div>
                        <span style={{ 
                          fontSize: "11px", fontWeight: "700", padding: "5px 12px", 
                          borderRadius: "20px", background: ss.bg, color: ss.text, 
                          border: `1px solid ${ss.border}`, textTransform: "uppercase", 
                          letterSpacing: "0.5px" 
                        }}>{d.status}</span>
                      </div>
                      <Pills duty={d} />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ─── LEAVE ADJUSTMENTS PAGE ─── */}
        {activeNav === "adjustments" && (
          <div>
            {/* Page Header */}
            <div style={{ marginBottom: "28px" }}>
              <h1 style={{ margin: 0, fontSize: "26px", fontWeight: "700", color: "#1e293b", letterSpacing: "-0.5px" }}>🔄 Leave Adjustments</h1>
              <p style={{ margin: "6px 0 0", fontSize: "14px", color: "#94a3b8" }}>Track duty swaps when teachers go on leave</p>
            </div>

            {/* Info Banner */}
            <div style={{
              marginBottom: "24px", padding: "18px 22px", borderRadius: "14px",
              background: "#eef9f7", border: "1px solid rgb(59 130 246) ",
              display: "flex", alignItems: "center", gap: "16px",
            }}>
              <div style={{ 
                width: "42px", height: "42px", borderRadius: "50%", 
                background: "rgb(47, 161, 196) ", display: "flex", alignItems: "center", 
                justifyContent: "center", fontSize: "20px", flexShrink: 0 
              }}>ℹ️</div>
              <div>
                <div style={{ fontSize: "15px", fontWeight: "700", color: "#0d9488", marginBottom: "3px" }}>How duty adjustments work</div>
                <div style={{ fontSize: "13px", color: "#64748b" }}>When a teacher goes on leave, their invigilation duties are automatically reassigned. All changes appear here for transparency.</div>
              </div>
            </div>

            {/* Filter Pills */}
            <div style={{ display: "flex", gap: "10px", marginBottom: "22px", flexWrap: "wrap" }}>
              {["All", "Confirmed", "Pending"].map((f) => {
                const isActive = activeFilter === f;
                return (
                  <span key={f} onClick={() => setActiveFilter(f)} style={{
                    padding: "7px 18px", borderRadius: "20px", fontSize: "13px", fontWeight: "600", cursor: "pointer", transition: "all 0.2s",
                    background: isActive ? "#0d9488" : "#fff",
                    color: isActive ? "#fff" : "#64748b",
                    border: isActive ? "1px solid #0d9488" : "1px solid #e2e8f0",
                    boxShadow: isActive ? "0 3px 10px rgba(13,148,136,0.3)" : "0 1px 3px rgba(0,0,0,0.05)",
                  }}
                    onMouseEnter={(e) => { if (!isActive) { e.currentTarget.style.background = "#f8fafc"; e.currentTarget.style.borderColor = "#cbd5e1"; }}}
                    onMouseLeave={(e) => { if (!isActive) { e.currentTarget.style.background = "#fff"; e.currentTarget.style.borderColor = "#e2e8f0"; }}}
                  >{f}</span>
                );
              })}
            </div>

            {/* Adjustment Cards */}
            <div style={{ display: "grid", gap: "16px" }}>
              {adjustments
                .filter((a) => activeFilter === "All" || a.status === activeFilter)
                .map((a) => {
                  const ss = statusLight[a.status];
                  const isMine = a.absentTeacher === teacher.name;
                  return (
                    <div key={a.id} style={{
                      background: isMine ? "#fdf2f8" : "#fff",
                      borderRadius: "14px", overflow: "hidden", transition: "all 0.22s",
                      border: isMine ? "1px solid #f9a8d4" : "1px solid #e2e8f0",
                      boxShadow: "0 2px 6px rgba(0,0,0,0.06)",
                    }}
                      onMouseEnter={(e) => { 
                        e.currentTarget.style.borderColor = isMine ? "#ec4899" : "rgb(8, 35, 77) "; 
                        e.currentTarget.style.boxShadow = isMine ? "0 6px 16px rgba(236,72,153,0.2)" : "0 6px 16px rgba(13,148,136,0.18)";
                        e.currentTarget.style.transform = "translateY(-2px)";
                      }}
                      onMouseLeave={(e) => { 
                        e.currentTarget.style.borderColor = isMine ? "#f9a8d4" : "#e2e8f0"; 
                        e.currentTarget.style.boxShadow = "0 2px 6px rgba(0,0,0,0.06)";
                        e.currentTarget.style.transform = "translateY(0)";
                      }}
                    >
                      <div style={{ height: "4px", background: isMine ? "linear-gradient(90deg,#ec4899,#f472b6)" : "linear-gradient(90deg,#14b8a6,#5eead4)" }}></div>

                      <div style={{ padding: "20px 22px" }}>
                        {/* Header */}
                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "16px" }}>
                          <div>
                            <div style={{ fontSize: "16px", fontWeight: "700", color: "#1e293b", marginBottom: "4px" }}>{a.exam}</div>
                            <div style={{ fontSize: "12px", color: "#94a3b8", fontWeight: "500" }}>{a.class} · {a.room}</div>
                          </div>
                          <div style={{ display: "flex", gap: "8px", alignItems: "center", flexWrap: "wrap", justifyContent: "flex-end" }}>
                            {isMine && (
                              <span style={{ 
                                fontSize: "10px", fontWeight: "700", padding: "4px 10px", 
                                borderRadius: "14px", background: "#fce7f3", color: "#db2777", 
                                border: "1px solid #f9a8d4", textTransform: "uppercase", 
                                letterSpacing: "0.5px" 
                              }}>Your Leave</span>
                            )}
                            <span style={{ 
                              fontSize: "11px", fontWeight: "700", padding: "5px 12px", 
                              borderRadius: "20px", background: ss.bg, color: ss.text, 
                              border: `1px solid ${ss.border}`, textTransform: "uppercase", 
                              letterSpacing: "0.5px" 
                            }}>{a.status}</span>
                          </div>
                        </div>

                        {/* Swap Row */}
                        <div style={{ 
                          display: "flex", alignItems: "center", gap: "12px", 
                          margin: "16px 0", padding: "16px 18px", borderRadius: "12px", 
                          background: "#f8fafc", border: "1px solid #e2e8f0" 
                        }}>
                          {/* Absent Teacher */}
                          <div style={{ flex: 1, textAlign: "center" }}>
                            <div style={{ 
                              fontSize: "10px", color: "#94a3b8", textTransform: "uppercase", 
                              letterSpacing: "0.7px", marginBottom: "8px", fontWeight: "700" 
                            }}>Absent</div>
                            <div style={{ 
                              display: "inline-flex", alignItems: "center", gap: "8px", 
                              padding: "8px 14px", borderRadius: "10px", 
                              background: "#fef2f2", border: "1px solid #fca5a5" 
                            }}>
                              <span style={{ 
                                width: "28px", height: "28px", borderRadius: "50%", 
                                background: "linear-gradient(135deg,#ef4444,#f87171)", 
                                display: "flex", alignItems: "center", justifyContent: "center", 
                                fontSize: "10px", fontWeight: "700", color: "#fff" 
                              }}>
                                {a.absentTeacher.split(" ").map((w) => w[0]).join("")}
                              </span>
                              <span style={{ fontSize: "13px", fontWeight: "600", color: "#dc2626" }}>{a.absentTeacher}</span>
                            </div>
                            <div style={{ fontSize: "11px", color: "#94a3b8", marginTop: "6px" }}>
                              Reason: <span style={{ color: "#64748b", fontWeight: "600" }}>{a.reason}</span>
                            </div>
                          </div>

                          {/* Arrow */}
                          <div style={{ fontSize: "24px", color: "#cbd5e1", flexShrink: 0 }}>⟶</div>

                          {/* Replacement Teacher */}
                          <div style={{ flex: 1, textAlign: "center" }}>
                            <div style={{ 
                              fontSize: "10px", color: "#94a3b8", textTransform: "uppercase", 
                              letterSpacing: "0.7px", marginBottom: "8px", fontWeight: "700" 
                            }}>Replaced By</div>
                            <div style={{ 
                              display: "inline-flex", alignItems: "center", gap: "8px", 
                              padding: "8px 14px", borderRadius: "10px", 
                              background: "#ecfdf5", border: "1px solid #6ee7b7" 
                            }}>
                              <span style={{ 
                                width: "28px", height: "28px", borderRadius: "50%", 
                                background: "linear-gradient(135deg,#14b8a6,#5eead4)", 
                                display: "flex", alignItems: "center", justifyContent: "center", 
                                fontSize: "10px", fontWeight: "700", color: "#fff" 
                              }}>
                                {a.replacedBy.split(" ").map((w) => w[0]).join("")}
                              </span>
                              <span style={{ fontSize: "13px", fontWeight: "600", color: "#0d9488" }}>{a.replacedBy}</span>
                            </div>
                          </div>
                        </div>

                        {/* Detail Pills */}
                        <Pills duty={{ class: a.class, room: a.room, date: a.originalDate, time: a.time }} />
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>
        )}
      </main>

      <style>{`
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 3px; }
        ::-webkit-scrollbar-thumb:hover { background: #94a3b8; }
      `}</style>
    </div>
  );
}