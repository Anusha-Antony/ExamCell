import React, { useState } from 'react';
import { Brain, Calendar, Users, FileText, LogOut, Menu, Clock, CheckCircle, AlertCircle, BarChart3, MapPin, Bell, Search, Plus } from 'lucide-react';

export default function AdminDashboard() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');

  const stats = [
    {
      title: 'Total Students',
      value: '2,458',
      change: '+12%',
      icon: Users,
      color: 'from-blue-500 to-indigo-600',
      trend: 'up'
    },
    {
      title: 'Scheduled Exams',
      value: '24',
      change: '+3',
      icon: Calendar,
      color: 'from-purple-500 to-pink-600',
      trend: 'up'
    },
    {
      title: 'Faculty Members',
      value: '156',
      change: '+8',
      icon: Users,
      color: 'from-green-500 to-emerald-600',
      trend: 'up'
    },
    {
      title: 'Exam Halls',
      value: '18',
      change: '0',
      icon: MapPin,
      color: 'from-orange-500 to-red-600',
      trend: 'neutral'
    }
  ];

  const upcomingExams = [
    {
      subject: 'Data Structures',
      date: '2026-02-15',
      time: '10:00 AM',
      hall: 'Hall A',
      students: 120,
      status: 'scheduled'
    },
    {
      subject: 'Database Management',
      date: '2026-02-18',
      time: '02:00 PM',
      hall: 'Hall B',
      students: 95,
      status: 'scheduled'
    },
    {
      subject: 'Computer Networks',
      date: '2026-02-20',
      time: '10:00 AM',
      hall: 'Hall C',
      students: 110,
      status: 'pending'
    },
    {
      subject: 'Operating Systems',
      date: '2026-02-22',
      time: '02:00 PM',
      hall: 'Hall A',
      students: 105,
      status: 'scheduled'
    }
  ];

  const recentActivities = [
    {
      action: 'New exam scheduled',
      subject: 'Data Structures',
      time: '2 hours ago',
      type: 'success'
    },
    {
      action: 'Hall allocation updated',
      subject: 'Database Management',
      time: '5 hours ago',
      type: 'info'
    },
    {
      action: 'Faculty duty assigned',
      subject: 'Computer Networks',
      time: '1 day ago',
      type: 'success'
    },
    {
      action: 'Student registration',
      subject: '15 new students',
      time: '2 days ago',
      type: 'info'
    }
  ];

  const menuItems = [
    { id: 'overview', name: 'Overview', icon: BarChart3, path: '/admin/overview' },
    { id: 'exams', name: 'SeriesInvigilation', icon: Calendar, path: '/SeriesInvigilation' },
    { id: 'settings', name: 'University Exams', icon: Calendar, path: '/UniversityInvigilation' },
    { id: 'halls', name: 'SeatingArrangement', icon: Users, path: '/SeatingArrangement' },
    { id: 'students', name: 'StudentsManagement', icon: Users, path: '/StudentsManagement' },
    { id: 'faculty', name: 'FacultyManagement', icon: Users, path: '/FacultyManagement' },
    // { id: 'reports', name: 'Reports', icon: FileText, path: '/admin/reports' }
  ];

  const handleNavigation = (item) => {
    setActiveTab(item.id);
    // Navigate to the corresponding page
    window.location.href = item.path;
  };

  const handleLogout = () => {
    window.location.href = '/login';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Sidebar */}
      <aside className={`fixed top-0 left-0 h-full bg-white shadow-xl transition-all duration-300 z-40 ${sidebarOpen ? 'w-64' : 'w-20'}`}>
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="p-6 border-b border-slate-200">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center">
                <Brain className="w-6 h-6 text-white" />
              </div>
              {sidebarOpen && (
                <div>
                  <h1 className="text-xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">InExa</h1>
                  <p className="text-xs text-slate-500">Admin Panel</p>
                </div>
              )}
            </div>
          </div>

          {/* Menu Items */}
          <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
            {menuItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavigation(item)}
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all ${
                    isActive
                      ? 'bg-gradient-to-r from-blue-500 to-indigo-600 text-white shadow-lg'
                      : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  {sidebarOpen && <span className="font-medium">{item.name}</span>}
                </button>
              );
            })}
          </nav>

          {/* Logout */}
          <div className="p-4 border-t border-slate-200">
            <button
              onClick={handleLogout}
              className="w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-red-600 hover:bg-red-50 transition-all"
            >
              <LogOut className="w-5 h-5" />
              {sidebarOpen && <span className="font-medium">Logout</span>}
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <div className={`transition-all duration-300 ${sidebarOpen ? 'ml-64' : 'ml-20'}`}>
        {/* Header */}
        <header className="bg-white shadow-sm sticky top-0 z-30">
          <div className="px-6 py-4 flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => setSidebarOpen(!sidebarOpen)}
                className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
              >
                <Menu className="w-6 h-6 text-slate-600" />
              </button>
              <div>
                <h2 className="text-2xl font-bold text-slate-800">Admin Dashboard</h2>
                <p className="text-sm text-slate-500">Welcome back, Administrator</p>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search..."
                  className="pl-10 pr-4 py-2 bg-slate-100 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 w-64"
                />
              </div>
              <button className="relative p-2 hover:bg-slate-100 rounded-lg transition-colors">
                <Bell className="w-6 h-6 text-slate-600" />
                <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
              </button>
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center">
                <span className="text-white font-semibold">A</span>
              </div>
            </div>
          </div>
        </header>

        {/* Dashboard Content */}
        <main className="p-6 space-y-6">
          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <div key={index} className="bg-white rounded-2xl shadow-lg p-6 border border-slate-100 hover:shadow-xl transition-all">
                  <div className="flex items-start justify-between mb-4">
                    <div className={`w-12 h-12 bg-gradient-to-br ${stat.color} rounded-xl flex items-center justify-center`}>
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <span className={`text-sm font-semibold px-2 py-1 rounded-full ${
                      stat.trend === 'up' ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-700'
                    }`}>
                      {stat.change}
                    </span>
                  </div>
                  <h3 className="text-slate-600 text-sm font-medium mb-1">{stat.title}</h3>
                  <p className="text-3xl font-bold text-slate-800">{stat.value}</p>
                </div>
              );
            })}
          </div>

          <div className="grid lg:grid-cols-3 gap-6">
            {/* Upcoming Exams */}
            <div className="lg:col-span-2 bg-white rounded-2xl shadow-lg p-6 border border-slate-100">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-slate-800">Upcoming Exams</h3>
                <button className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-lg hover:shadow-lg transition-all">
                  <Plus className="w-4 h-4" />
                  Schedule Exam
                </button>
              </div>

              <div className="space-y-4">
                {upcomingExams.map((exam, index) => (
                  <div key={index} className="p-4 bg-slate-50 rounded-xl border border-slate-200 hover:border-blue-300 transition-all">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-bold text-slate-800">{exam.subject}</h4>
                      <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                        exam.status === 'scheduled'
                          ? 'bg-green-100 text-green-700'
                          : 'bg-yellow-100 text-yellow-700'
                      }`}>
                        {exam.status}
                      </span>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm text-slate-600">
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4" />
                        {exam.date}
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4" />
                        {exam.time}
                      </div>
                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4" />
                        {exam.hall}
                      </div>
                      <div className="flex items-center gap-2">
                        <Users className="w-4 h-4" />
                        {exam.students} students
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Recent Activities */}
            <div className="bg-white rounded-2xl shadow-lg p-6 border border-slate-100">
              <h3 className="text-xl font-bold text-slate-800 mb-6">Recent Activities</h3>
              <div className="space-y-4">
                {recentActivities.map((activity, index) => (
                  <div key={index} className="flex items-start gap-3 pb-4 border-b border-slate-100 last:border-0">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                      activity.type === 'success'
                        ? 'bg-green-100'
                        : 'bg-blue-100'
                    }`}>
                      {activity.type === 'success' ? (
                        <CheckCircle className="w-4 h-4 text-green-600" />
                      ) : (
                        <AlertCircle className="w-4 h-4 text-blue-600" />
                      )}
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-slate-800">{activity.action}</p>
                      <p className="text-xs text-slate-500">{activity.subject}</p>
                      <p className="text-xs text-slate-400 mt-1">{activity.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="bg-white rounded-2xl shadow-lg p-6 border border-slate-100">
            <h3 className="text-xl font-bold text-slate-800 mb-6">Quick Actions</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { name: 'Schedule Exam', icon: Calendar, color: 'from-blue-500 to-indigo-600' },
                { name: 'Add Student', icon: Users, color: 'from-green-500 to-emerald-600' },
                { name: 'Assign Duty', icon: FileText, color: 'from-purple-500 to-pink-600' },
                { name: 'Generate Report', icon: BarChart3, color: 'from-orange-500 to-red-600' }
              ].map((action, index) => {
                const Icon = action.icon;
                return (
                  <button
                    key={index}
                    className="p-6 bg-slate-50 rounded-xl border-2 border-slate-200 hover:border-blue-300 transition-all hover:shadow-lg group"
                  >
                    <div className={`w-12 h-12 bg-gradient-to-br ${action.color} rounded-xl flex items-center justify-center mb-3 group-hover:scale-110 transition-transform`}>
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <p className="text-sm font-semibold text-slate-700">{action.name}</p>
                  </button>
                );
              })}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
