const mongoose = require("mongoose");

const studentSchema = new mongoose.Schema({
  fullName: String,
  rollNumber: String,
  email: String,
  phone: String,
  dateOfBirth: Date,
  department: String,
  semester: String,
  password: String,
  confirmPassword:String
});

module.exports = mongoose.model("Student", studentSchema);